import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { Lesson, ChecklistItem, LessonComment, Presence } from "./src/types";

dotenv.config();

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(process.cwd(), "data", "lessons_data.json");
const USERS_FILE = path.join(process.cwd(), "data", "users_data.json");

app.use(express.json());

interface UserProfile {
  id: string;
  username: string;
  password?: string;
  name: string;
  role: 'teacher' | 'student';
  avatar: string;
}

const getInitialUsers = (): UserProfile[] => {
  return [
    { id: "auth-teach-1", username: "cooper", password: "123", name: "Ms. Cooper", role: "teacher", avatar: "👩‍🏫" },
    { id: "auth-teach-2", username: "harrison", password: "123", name: "Mr. Harrison", role: "teacher", avatar: "👨‍🏫" },
    { id: "auth-stud-1", username: "sophia", password: "123", name: "Sophia", role: "student", avatar: "👩‍🎓" },
    { id: "auth-stud-2", username: "liam", password: "123", name: "Liam", role: "student", avatar: "👨‍🎓" }
  ];
};

const loadUsers = (): UserProfile[] => {
  try {
    if (fs.existsSync(USERS_FILE)) {
      const content = fs.readFileSync(USERS_FILE, "utf-8");
      return JSON.parse(content);
    }
  } catch (error) {
    console.error("Error loading users from local database:", error);
  }
  
  const initial = getInitialUsers();
  saveUsers(initial);
  return initial;
};

const saveUsers = (users: UserProfile[]) => {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), "utf-8");
  } catch (error) {
    console.error("Error writing users to local database:", error);
  }
};

let usersStore: UserProfile[] = loadUsers();

// Initial Sample Data to make the application look immediately professional and rich
const getInitialLessons = (): Lesson[] => {
  const todayStr = new Date().toISOString().split('T')[0];
  
  // Calculate tomorrow
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  // Calculate yesterday
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  return [
    {
      id: "lesson-1",
      title: "Solar Physics & Corona Dynamics",
      subject: "Science",
      gradeLevel: "Sophia",
      duration: 60,
      date: todayStr,
      startTime: "10:00",
      endTime: "11:00",
      objectives: "1. Describe the structure of the solar atmosphere.\n2. Understand magnetic field reconnection events driving solar coronal mass ejections (CMEs).\n3. Match electromagnetic emission ranges to solar observatory filters.",
      outline: `### Lesson Progression

#### 1. Warm-up: Solar Weather (10 mins)
- Brief showcase of the Solar Dynamics Observatory's live 171Å feed.
- Classroom discussion: What happens when modern satellite systems intercept a Carrington-class CME?

#### 2. Direct Instruction: Coronal Stratification (20 mins)
- Breakdown of chromosphere, transition region, and outer corona temperature anomalies (1 million Kelvin mystery).
- Visualizing solar magnetic loops and plasma confinement.

#### 3. Group Activity: Filter Mapping (20 mins)
- Students pair up to map solar spectrum lines (H-Alpha, Calcium-II K, Fe IX) to their diagnostic temperatures in a Google workbook.

#### 4. Exit Ticket / Quiz (10 mins)
- Brief evaluation: Define why high energy emissions originate in coronal regions rather than the cold photosphere.`,
      materials: [
        "Solar Dynamics Observatory online portal link",
        "Spectroscopy analysis printouts",
        "Diffraction grating sliders"
      ],
      checklist: [
        { id: "c1-1", text: "Download diagnostic maps and student worksheet.", completed: true, role: "teacher" },
        { id: "c1-2", text: "Setup classroom projector with solar live-stream.", completed: true, role: "teacher" },
        { id: "c1-3", text: "Complete pre-class reading on photosphere structure.", completed: true, role: "student" },
        { id: "c1-4", text: "Bring colored charting pens for filter mapping.", completed: false, role: "student" },
        { id: "c1-5", text: "Submit Group Diagnostic Handout by end of hour.", completed: false, role: "both" }
      ],
      comments: [
        {
          id: "m1-1",
          authorId: "auth-teach-1",
          authorName: "Ms. Cooper",
          authorRole: "teacher",
          text: "Welcome students! Please review the pre-read material about solar magnetic structures. We'll be doing a live demonstration using solar software tomorrow.",
          timestamp: new Date(Date.now() - 3600000 * 4).toISOString()
        },
        {
          id: "m1-2",
          authorId: "auth-stud-1",
          authorName: "Sophia (Student)",
          authorRole: "student",
          text: "I read Chapter 4 on coronal temperatures! Is it true that the heating is caused by nanoflares?",
          timestamp: new Date(Date.now() - 3600000 * 2.5).toISOString()
        },
        {
          id: "m1-3",
          authorId: "auth-teach-1",
          authorName: "Ms. Cooper",
          authorRole: "teacher",
          text: "Spot on, Sophia! Magnetic reconnection and Alfvén wave models are the leading theories. We will compare both in our active lab work.",
          timestamp: new Date(Date.now() - 3600000).toISOString()
        }
      ],
      status: "scheduled",
      teachers: ["Ms. Cooper"],
      students: ["auth-stud-1"],
      reminders: [5, 15]
    },
    {
      id: "lesson-2",
      title: "Superposition and Quantum Circuits",
      subject: "Computer Science",
      gradeLevel: "Liam",
      duration: 90,
      date: tomorrowStr,
      startTime: "13:00",
      endTime: "14:30",
      objectives: "1. Implement single-qubit gates (Hadamard, Pauli-X) inside circuit graphs.\n2. Quantify measurement probabilities from mixed quantum states.\n3. Identify computational bottlenecks resolved by quantum computing algorithms.",
      outline: `### Quantum Circuits Introduction

#### 1. Classical vs Quantum (15 mins)
- Conceptualize bit strings vs multi-dimensional state hyperspheres (Bloch Sphere).

#### 2. The Hadamard Portal (30 mins)
- Math session: Expressing the Hadamard transform on standard |0⟩ and |1⟩ inputs.
- Active visual plotting of standard probabilities.

#### 3. Direct Lab: Qubit Gates Playground (35 mins)
- Interactive Jupyter Notebook playground testing circuit outputs in simulators.
- Creating EPR entangled pairs using Hadamard and CNOT gates.

#### 4. Retro / Debrief (10 mins)
- Group discussion: Why does measuring state collapse the quantum potential?`,
      materials: [
        "Web Quantum Composer account credentials",
        "Linear Algebra cheat-sheets (matrix multiplication, vectors)",
        "Computing superposition guidelines"
      ],
      checklist: [
        { id: "c2-1", text: "Verify Docker containers for Jupyter Lab are running.", completed: false, role: "teacher" },
        { id: "c2-2", text: "Complete linear algebra refresher worksheet.", completed: true, role: "student" },
        { id: "c2-3", text: "Run EPR entanglement simulation.", completed: false, role: "both" }
      ],
      comments: [
        {
          id: "m2-1",
          authorId: "auth-stud-2",
          authorName: "Liam (Student)",
          authorRole: "student",
          text: "Does the quantum simulator handle more than 3 qubits? I tried running a multi-gate entangler earlier and had some latency.",
          timestamp: new Date(Date.now() - 3600000 * 8).toISOString()
        },
        {
          id: "m2-2",
          authorId: "auth-teach-1",
          authorName: "Ms. Cooper",
          authorRole: "teacher",
          text: "Hi Liam, yes, our simulator handles up to 5 qubits. I will check the memory config on our local server to optimize the speed.",
          timestamp: new Date(Date.now() - 3600000 * 7).toISOString()
        }
      ],
      status: "draft",
      teachers: ["Ms. Cooper"],
      students: ["auth-stud-2"],
      reminders: [15]
    },
    {
      id: "lesson-3",
      title: "Creative Writing: Narrative Arc and Tension",
      subject: "Secondary Humanities",
      gradeLevel: "Sophia",
      duration: 75,
      date: yesterdayStr,
      startTime: "09:00",
      endTime: "10:15",
      objectives: "1. Outline Freytag's Pyramid on a literary excerpt.\n2. Contrast pacing and dialog density in tense dramatic passages.\n3. Write a 200-word micro-narrative incorporating delayed revelation mechanics.",
      outline: `### Narrative Tension Outlines

#### 1. Quick Write (15 mins)
- Write for 5 mins about a dripping faucet from the perspective of someone hiding. Review pacing adjustments.

#### 2. Structural breakdown (30 mins)
- Analyzing a short segment from Edgar Allan Poe. Tracking sentence length vs heartbeat pace.

#### 3. Collaborative Draft (20 mins)
- Peer review dyads: exchanging drafts and highlighting where readers felt the focus slowing.

#### 4. Wrap & Outpatient logs (10 mins)
- Storing drafting tips to private creative diaries.`,
      materials: [
        "The Tell-Tale Heart excerpt booklet",
        "Graphing charts for pacing index"
      ],
      checklist: [
        { id: "c3-1", text: "Upload Edgar Allan Poe excerpt resources.", completed: true, role: "teacher" },
        { id: "c3-2", text: "Prepare narrative feedback rubric.", completed: true, role: "teacher" },
        { id: "c3-3", text: "Draft narrative paragraph focusing on sensory detail.", completed: true, role: "student" }
      ],
      comments: [],
      status: "completed",
      teachers: ["Mr. Harrison"],
      students: ["auth-stud-1"],
      reminders: []
    }
  ];
};

// Reading and writing helpers for local persistent database
const loadLessons = (): Lesson[] => {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, "utf-8");
      return JSON.parse(content);
    }
  } catch (error) {
    console.error("Error loading lessons from local database:", error);
  }
  
  // Create initial file
  const initial = getInitialLessons();
  saveLessons(initial);
  return initial;
};

const saveLessons = (lessons: Lesson[]) => {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(lessons, null, 2), "utf-8");
  } catch (error) {
    console.error("Error writing lessons to local database:", error);
  }
};

// State Managers (Durable persistent database)
let lessonsStore: Lesson[] = loadLessons();

// Keep track of presence (in-memory, swept every 12 seconds)
let presences: Map<string, Presence> = new Map();

// Server-Sent Events clients
let sseClients: { id: string; userId?: string; role?: string; res: express.Response }[] = [];

// Clean up stale client presences
setInterval(() => {
  const tenSecondsAgo = new Date(Date.now() - 12000).toISOString();
  let changed = false;
  for (const [userId, presence] of presences.entries()) {
    if (presence.lastSeen < tenSecondsAgo) {
      presences.delete(userId);
      changed = true;
    }
  }
  if (changed) {
    broadcast("presence_changed", Array.from(presences.values()));
  }
}, 5000);

// Broadcast utility
const broadcast = (type: string, data: any) => {
  if (type === "lessons_updated" || type === "sync_lessons") {
    sseClients.forEach(client => {
      let filtered = data;
      if (client.role === "student" && client.userId) {
        filtered = data.filter((l: Lesson) => l.students && l.students.includes(client.userId!));
      }
      try {
        client.res.write(`data: ${JSON.stringify({ type, data: filtered })}\n\n`);
      } catch (e) {
        // client dropped
      }
    });
    return;
  }

  if (type === "presence_changed") {
    sseClients.forEach(client => {
      let filtered = data;
      if (client.role === "student" && client.userId) {
        // Students only see themselves and teachers
        filtered = data.filter((p: Presence) => p.userId === client.userId || p.userRole === "teacher");
      }
      try {
        client.res.write(`data: ${JSON.stringify({ type, data: filtered })}\n\n`);
      } catch (e) {
        // client dropped
      }
    });
    return;
  }

  const payload = JSON.stringify({ type, data });
  sseClients.forEach(client => {
    try {
      client.res.write(`data: ${payload}\n\n`);
    } catch (e) {
      // client dropped
    }
  });
};

// API: Server-Sent Events Connection Endpoint
app.get("/api/events", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  const userId = req.query.userId as string;
  const role = req.query.role as string;

  const clientSocketId = Date.now().toString() + Math.random().toString(36).substring(2, 6);
  sseClients.push({ id: clientSocketId, userId, role, res });

  // Flush headers
  res.write(`data: ${JSON.stringify({ type: "handshake", clientSocketId })}\n\n`);
  
  // Immediately send initial datasets to sync state (filtered specifically for students)
  let filteredLessons = lessonsStore;
  if (role === "student" && userId) {
    filteredLessons = lessonsStore.filter(l => l.students && l.students.includes(userId));
  }
  res.write(`data: ${JSON.stringify({ type: "sync_lessons", data: filteredLessons })}\n\n`);

  let filteredPresence = Array.from(presences.values());
  if (role === "student" && userId) {
    filteredPresence = filteredPresence.filter(p => p.userId === userId || p.userRole === "teacher");
  }
  res.write(`data: ${JSON.stringify({ type: "presence_changed", data: filteredPresence })}\n\n`);

  req.on("close", () => {
    sseClients = sseClients.filter(c => c.id !== clientSocketId);
  });
});

// REST ENDPOINTS

// 0. Get registered students
app.get("/api/users/students", (req, res) => {
  const students = usersStore.filter(u => u.role === "student");
  res.json(students.map(u => ({ id: u.id, name: u.name, username: u.username, avatar: u.avatar })));
});

// 1. Get lessons list
app.get("/api/lessons", (req, res) => {
  const userId = (req.query.userId || req.headers["x-user-id"]) as string;
  const role = (req.query.role || req.headers["x-user-role"]) as string;
  
  if (role === "student" && userId) {
    res.json(lessonsStore.filter(l => l.students && l.students.includes(userId)));
  } else {
    res.json(lessonsStore);
  }
});

// 2. Create lesson plan
app.post("/api/lessons", (req, res) => {
  const newLesson: Lesson = {
    id: "lesson-" + Date.now().toString() + Math.random().toString(36).substring(2, 5),
    title: req.body.title || "Untitled Lesson",
    subject: req.body.subject || "General Study",
    gradeLevel: req.body.gradeLevel || "All Grades",
    duration: Number(req.body.duration) || 45,
    date: req.body.date || new Date().toISOString().split('T')[0],
    startTime: req.body.startTime || "09:00",
    endTime: req.body.endTime || "09:45",
    objectives: req.body.objectives || "",
    outline: req.body.outline || "### Introduction\n- Topic start\n\n### Core Activities\n- Hands on lab\n\n### Wrap-up\n- Reflection and exit summary",
    materials: req.body.materials || [],
    checklist: req.body.checklist || [],
    comments: [],
    status: req.body.status || "draft",
    teachers: req.body.teachers || ["Staff"],
    students: req.body.students || ["General Students Assembly"],
    reminders: req.body.reminders || [15],
    color: req.body.color
  };

  lessonsStore.push(newLesson);
  saveLessons(lessonsStore);
  broadcast("lessons_updated", lessonsStore);
  res.status(201).json(newLesson);
});

// 3. Update lesson plan
app.put("/api/lessons/:id", (req, res) => {
  const lessonId = req.params.id;
  const index = lessonsStore.findIndex(l => l.id === lessonId);
  if (index === -1) {
    res.status(404).json({ error: "Lesson not found" });
    return;
  }

  // Update original fields while preserving ID and core structures
  const existing = lessonsStore[index];
  lessonsStore[index] = {
    ...existing,
    ...req.body,
    id: existing.id, // Immutable ID
    comments: req.body.comments || existing.comments // Maintain comments through specialized endpoint or direct edit
  };

  saveLessons(lessonsStore);
  broadcast("lessons_updated", lessonsStore);
  res.json(lessonsStore[index]);
});

// 4. Delete lesson plan
app.delete("/api/lessons/:id", (req, res) => {
  const lessonId = req.params.id;
  const initialLength = lessonsStore.length;
  lessonsStore = lessonsStore.filter(l => l.id !== lessonId);
  
  if (lessonsStore.length === initialLength) {
    res.status(404).json({ error: "Lesson not found" });
    return;
  }

  saveLessons(lessonsStore);
  broadcast("lessons_updated", lessonsStore);
  res.json({ success: true, deletedId: lessonId });
});

// 5. Add collaborative comment/chat log
app.post("/api/lessons/:id/comments", (req, res) => {
  const lessonId = req.params.id;
  const index = lessonsStore.findIndex(l => l.id === lessonId);
  if (index === -1) {
    res.status(404).json({ error: "Lesson not found" });
    return;
  }

  const comment: LessonComment = {
    id: "comment-" + Date.now().toString() + Math.random().toString(36).substring(2, 5),
    authorId: req.body.authorId || "staff-member",
    authorName: req.body.authorName || "Anonymous Writer",
    authorRole: req.body.authorRole || "teacher",
    text: req.body.text || "",
    timestamp: new Date().toISOString()
  };

  lessonsStore[index].comments.push(comment);
  saveLessons(lessonsStore);
  broadcast("lessons_updated", lessonsStore);
  res.status(201).json(comment);
});

// 6. User active presence reporting
app.post("/api/presence", (req, res) => {
  const { userId, userName, userRole, activeLessonId } = req.body;
  if (!userId) {
    res.status(400).json({ error: "userId required" });
    return;
  }

  const current: Presence = {
    userId,
    userName: userName || "Incognito Guest",
    userRole: userRole || "student",
    activeLessonId: activeLessonId || null,
    lastSeen: new Date().toISOString()
  };

  presences.set(userId, current);
  broadcast("presence_changed", Array.from(presences.values()));
  res.json({ success: true, activePresences: Array.from(presences.values()) });
});

// 7. Proper User Registration and Login Auth Endpoints
app.post("/api/auth/register", (req, res) => {
  const { username, password, name, role, avatar } = req.body;
  if (!username || !password || !name || !role) {
    res.status(400).json({ error: "All profile registration fields are required" });
    return;
  }

  const cleanUsername = username.trim().toLowerCase();
  const exists = usersStore.find(u => u.username === cleanUsername);
  if (exists) {
    res.status(400).json({ error: "Username is already registered" });
    return;
  }

  const newUser: UserProfile = {
    id: "user-" + Date.now().toString() + Math.random().toString(36).substring(2, 5),
    username: cleanUsername,
    password: password.trim(),
    name: name.trim(),
    role: role === "teacher" ? "teacher" : "student",
    avatar: avatar || (role === "teacher" ? "👩‍🏫" : "👩‍🎓")
  };

  usersStore.push(newUser);
  saveUsers(usersStore);

  // Return user details safely without leaking password
  const { password: _, ...safeUser } = newUser;
  res.status(201).json({ success: true, user: safeUser });
});

app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: "Username and password are required" });
    return;
  }

  const cleanUsername = username.trim().toLowerCase();
  const user = usersStore.find(u => u.username === cleanUsername);
  if (!user || user.password !== password.trim()) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  const { password: _, ...safeUser } = user;
  res.json({ success: true, user: safeUser });
});


// FRONTEND ASSETS AND RUNTIME ROUTING

// If we are in development, Vite handles static assets; in production, serve built dist files.
if (process.env.NODE_ENV !== "production") {
  createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  }).then((vite) => {
    app.use(vite.middlewares);
    
    // Fallback catch-all for single page apps in Dev
    app.get("*", (req, res, next) => {
      // Allow API routes to slide through
      if (req.path.startsWith("/api/")) {
        next();
        return;
      }
      
      const indexHtmlPath = path.join(process.cwd(), "index.html");
      let html = fs.readFileSync(indexHtmlPath, "utf-8");
      
      // Inject standard dev server headers
      vite.transformIndexHtml(req.url, html).then((transformedHtml) => {
        res.status(200).set({ "Content-Type": "text/html" }).end(transformedHtml);
      }).catch(next);
    });
  });
} else {
  // Built files serving for production
  const distPath = path.join(process.cwd(), "dist");
  app.use(express.static(distPath));
  
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api/")) {
      res.status(404).json({ error: "API route not found" });
      return;
    }
    res.sendFile(path.join(distPath, "index.html"));
  });
}

// Start listener
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Lessons Collaboration Hub booting. Listening on port ${PORT}`);
});
