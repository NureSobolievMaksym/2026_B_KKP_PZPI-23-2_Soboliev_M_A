import React, { useState, useEffect, useRef } from "react";
import { Lesson, AppUser, ChecklistItem, Presence } from "../types";
import {
  FileText, CheckSquare, MessageSquare, Clock, Users, 
  Plus, Check, Trash2, Edit3, BookOpen
} from "lucide-react";

interface LessonDetailPanelProps {
  lesson: Lesson;
  currentUser: AppUser;
  presences: Presence[];
  onUpdateLesson: (updated: Partial<Lesson>) => Promise<void>;
  onAddComment: (text: string) => Promise<void>;
  onDeleteLesson: (id: string) => void;
  onClose: () => void;
}

// Simple internal Markdown-to-HTML formatter with support for dark mode classes
function renderSimpleMarkdown(md: string): string {
  if (!md) return "<p class='text-slate-400 dark:text-slate-500 italic'>No outline details captured</p>";
  
  return md
    .split("\n")
    .map(line => {
      let trimmed = line.trim();
      if (trimmed.startsWith("#### ")) {
        return `<h5 class="text-xs font-bold text-slate-800 dark:text-slate-300 uppercase tracking-wide mt-3 mb-1">${trimmed.substring(5)}</h5>`;
      }
      if (trimmed.startsWith("### ")) {
        return `<h4 class="text-sm font-extrabold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-1 mt-4 mb-2 flex items-center gap-1"><span class="w-1 bg-indigo-500 h-4 rounded"></span>${trimmed.substring(4)}</h4>`;
      }
      if (trimmed.startsWith("## ")) {
        return `<h3 class="text-base font-extrabold text-slate-900 dark:text-slate-100 mt-5 mb-2">${trimmed.substring(3)}</h3>`;
      }
      if (trimmed.startsWith("- ")) {
        return `<li class="ml-4 list-disc text-xs text-slate-600 dark:text-slate-300 mb-1">${trimmed.substring(2)}</li>`;
      }
      if (trimmed.startsWith("* ")) {
        return `<li class="ml-4 list-disc text-xs text-slate-600 dark:text-slate-300 mb-1">${trimmed.substring(2)}</li>`;
      }
      if (trimmed === "") {
        return "<div class='h-2'></div>";
      }
      
      // Inline Bolding **text** -> <strong>text</strong>
      let formatted = trimmed.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
      return `<p class="text-xs text-slate-600 dark:text-slate-350 leading-relaxed mb-2">${formatted}</p>`;
    })
    .join("");
}

export default function LessonDetailPanel({
  lesson,
  currentUser,
  presences,
  onUpdateLesson,
  onAddComment,
  onDeleteLesson,
  onClose
}: LessonDetailPanelProps) {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<"plan" | "checklist" | "chat">("plan");
  
  // Presence calculation
  const lessonPresences = presences.filter(p => p.activeLessonId === lesson.id && p.userId !== currentUser.id);

  // Delete confirmation overlay
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Edit fields
  const [isEditingMetadata, setIsEditingMetadata] = useState(false);
  const [editTitle, setEditTitle] = useState(lesson.title);
  const [editSubject, setEditSubject] = useState(lesson.subject);
  const [editGradeLevel, setEditGradeLevel] = useState(lesson.gradeLevel);
  const [editDuration, setEditDuration] = useState(lesson.duration);
  const [editStartTime, setEditStartTime] = useState(lesson.startTime);
  const [editStatus, setEditStatus] = useState(lesson.status);
  const [editStudentId, setEditStudentId] = useState(lesson.students?.[0] || "");
  const [studentsList, setStudentsList] = useState<{ id: string; name: string; avatar: string }[]>([]);
  
  // Plan texts
  const [editObjectives, setEditObjectives] = useState(lesson.objectives);
  const [editOutline, setEditOutline] = useState(lesson.outline);
  const [isEditingPlanTexts, setIsEditingPlanTexts] = useState(false);

  // Items inputs
  const [newMaterialText, setNewMaterialText] = useState("");
  const [newChecklistText, setNewChecklistText] = useState("");
  const [newChecklistRole, setNewChecklistRole] = useState<'teacher' | 'student' | 'both'>("both");

  // Comment input
  const [commentText, setCommentText] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Fetch registered students when edit mode is triggered
  useEffect(() => {
    if (isEditingMetadata) {
      fetch("/api/users/students")
        .then(res => res.json())
        .then(data => {
          setStudentsList(data);
          const currentId = lesson.students?.[0] || (data[0] ? data[0].id : "");
          setEditStudentId(currentId);
        })
        .catch(err => console.error("Error loading students list in detail panel:", err));
    }
  }, [isEditingMetadata, lesson.students]);

  const handleEditStudentChange = (studentId: string) => {
    setEditStudentId(studentId);
    const chosen = studentsList.find(s => s.id === studentId);
    if (chosen) {
      setEditGradeLevel(chosen.name);
    }
  };

  // ИСПРАВЛЕНИЕ: Синхронизируем стейт только тогда, когда физически изменился ID урока,
  // либо если данные пришли снаружи, но пользователь НЕ находится в режиме активного редактирования метаданных.
  useEffect(() => {
    if (!isEditingMetadata) {
      setEditTitle(lesson.title);
      setEditSubject(lesson.subject);
      setEditGradeLevel(lesson.gradeLevel);
      setEditDuration(lesson.duration);
      setEditStartTime(lesson.startTime);
      setEditStatus(lesson.status);
      setEditStudentId(lesson.students?.[0] || "");
    }
  }, [lesson.id, lesson.title, lesson.subject, lesson.gradeLevel, lesson.duration, lesson.startTime, lesson.status, lesson.students, isEditingMetadata]);

  // ИСПРАВЛЕНИЕ: Изолированная синхронизация контента (Objectives & Outline) — только если не открыто окно их редактирования.
  useEffect(() => {
    if (!isEditingPlanTexts) {
      setEditObjectives(lesson.objectives);
      setEditOutline(lesson.outline);
    }
  }, [lesson.id, lesson.objectives, lesson.outline, isEditingPlanTexts]);

  // Scroll to bottom of chat
  useEffect(() => {
    if (activeTab === "chat") {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [lesson.comments, activeTab]);

  const handleSaveMetadata = async () => {
    let endTime = lesson.endTime;
    try {
      const [h, m] = editStartTime.split(":").map(Number);
      const totalMinutes = h * 60 + m + Number(editDuration);
      const endH = Math.floor(totalMinutes / 60) % 24;
      const endM = totalMinutes % 60;
      endTime = `${String(endH).padStart(2, "0")}:${String(endM).padStart(2, "0")}`;
    } catch (e) {
      // safe fallback
    }

    await onUpdateLesson({
      title: editTitle,
      subject: editSubject,
      gradeLevel: editGradeLevel,
      duration: Number(editDuration),
      startTime: editStartTime,
      endTime,
      status: editStatus,
      students: editStudentId ? [editStudentId] : []
    });
    setIsEditingMetadata(false);
  };

  const handleSavePlanTexts = async () => {
    await onUpdateLesson({
      objectives: editObjectives,
      outline: editOutline
    });
    setIsEditingPlanTexts(false);
  };

  // Checklist Check Sync
  const handleToggleCheckItem = async (itemId: string, currentCompleted: boolean) => {
    const updatedChecklist = lesson.checklist.map(item => 
      item.id === itemId ? { ...item, completed: !currentCompleted } : item
    );
    await onUpdateLesson({ checklist: updatedChecklist });
  };

  // Add Item Checklist
  const handleAddChecklistItem = async () => {
    if (!newChecklistText.trim()) return;
    const newItem: ChecklistItem = {
      id: "item-" + Date.now().toString() + Math.random().toString(36).substring(2, 4),
      text: newChecklistText.trim(),
      completed: false,
      role: newChecklistRole
    };
    await onUpdateLesson({
      checklist: [...lesson.checklist, newItem]
    });
    setNewChecklistText("");
  };

  // Delete Item Checklist
  const handleDeleteChecklistItem = async (itemId: string) => {
    const updated = lesson.checklist.filter(item => item.id !== itemId);
    await onUpdateLesson({ checklist: updated });
  };

  // Materials modifier
  const handleAddMaterial = async () => {
    if (!newMaterialText.trim()) return;
    await onUpdateLesson({
      materials: [...lesson.materials, newMaterialText.trim()]
    });
    setNewMaterialText("");
  };

  const handleDeleteMaterial = async (indexToDelete: number) => {
    const updated = lesson.materials.filter((_, idx) => idx !== indexToDelete);
    await onUpdateLesson({ materials: updated });
  };

  // Add Comment
  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    await onAddComment(commentText.trim());
    setCommentText("");
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md border border-slate-200 dark:border-slate-800 overflow-hidden h-full flex flex-col" id="lesson-detail-panel">
      {/* Detail Header Panels */}
      <div className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-805 dark:text-indigo-400 uppercase tracking-wide">
                {lesson.subject}
              </span>
              <span className="text-xs text-slate-550 dark:text-slate-400 font-medium flex items-center gap-1">
                <span className="text-slate-405 dark:text-slate-505">👤</span> {lesson.gradeLevel}
              </span>
              <span className="text-xs text-slate-400 dark:text-slate-600">•</span>
              <span className="text-xs text-slate-505 dark:text-slate-400 font-medium font-mono">
                {lesson.startTime} - {lesson.endTime} ({lesson.duration}m)
              </span>

              {/* Status Badge */}
              <span className={`text-[10px] px-2 py-0.5 font-bold rounded-full border hidden sm:inline ${
                lesson.status === 'completed' ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-250 dark:border-slate-700' :
                lesson.status === 'scheduled' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900' :
                lesson.status === 'active' ? 'bg-rose-55 dark:bg-rose-950 text-rose-800 dark:text-rose-400 border-rose-200 dark:border-rose-900 animate-pulse' :
                'bg-amber-50 dark:bg-amber-955 text-amber-800 dark:text-amber-400 border-amber-200 dark:border-amber-900'
              }`}>
                {lesson.status.toUpperCase()}
              </span>
            </div>

            {isEditingMetadata ? (
              <div className="mt-2 flex flex-col gap-2 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-lg max-w-md shadow-xs">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">Lesson Title</label>
                  <input
                    id="edit-title-input"
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-950 rounded mt-0.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">Subject</label>
                    <select
                      id="edit-subject-select"
                      value={editSubject}
                      onChange={(e) => setEditSubject(e.target.value)}
                      className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-750 rounded mt-0.5 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Science">Science</option>
                      <option value="Computer Science">Computer Science</option>
                      <option value="Secondary Humanities">Secondary Humanities</option>
                      <option value="Mathematics">Mathematics</option>
                      <option value="General Study">General Study</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">Assigned Student (Pupil)</label>
                    <select
                      id="edit-student-select"
                      value={editStudentId}
                      onChange={(e) => handleEditStudentChange(e.target.value)}
                      className="w-full text-xs p-1.5 border border-slate-200 dark:border-slate-755 rounded mt-0.5 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 focus:outline-none"
                    >
                      {studentsList.map((stud) => (
                        <option key={stud.id} value={stud.id}>
                          {stud.avatar} {stud.name}
                        </option>
                      ))}
                      {studentsList.length === 0 && (
                        <option value="">No students available</option>
                      )}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">Start (Time)</label>
                    <input
                      id="edit-start-input"
                      type="time"
                      value={editStartTime}
                      onChange={(e) => setEditStartTime(e.target.value)}
                      className="w-full text-xs p-1 border border-slate-200 dark:border-slate-750 rounded mt-0.5 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-mono focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">Duration (mins)</label>
                    <input
                      id="edit-duration-input"
                      type="number"
                      value={editDuration}
                      onChange={(e) => setEditDuration(Number(e.target.value))}
                      className="w-full text-xs p-1 border border-slate-200 dark:border-slate-750 rounded mt-0.5 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-mono focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">Status</label>
                    <select
                      id="edit-status-select"
                      value={editStatus}
                      onChange={(e) => setEditStatus(e.target.value as any)}
                      className="w-full text-xs p-1 border border-slate-200 dark:border-slate-755 rounded mt-0.5 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 focus:outline-none"
                    >
                      <option value="draft">Draft</option>
                      <option value="scheduled">Scheduled</option>
                      <option value="active">Active</option>
                      <option value="completed">Completed</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end gap-1.5 mt-1 pt-1.5 border-t border-slate-100 dark:border-slate-800">
                  <button
                    id="btn-cancel-meta-edit"
                    onClick={() => setIsEditingMetadata(false)}
                    className="px-2 py-1 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-850 text-[10px] rounded font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    id="btn-save-meta-edit"
                    onClick={handleSaveMetadata}
                    className="px-2.5 py-1 bg-indigo-600 text-white hover:bg-indigo-700 text-[10px] rounded font-semibold cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 mt-1">
                <h1 className="text-lg font-bold text-slate-900 dark:text-slate-100 tracking-tight leading-snug">
                  {lesson.title}
                </h1>
                {currentUser.role === 'teacher' && (
                  <button
                    id="btn-trigger-meta-edit"
                    onClick={() => setIsEditingMetadata(true)}
                    className="p-1 hover:bg-slate-150 dark:hover:bg-slate-800 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer transition-colors"
                    title="Edit Metadata"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2 items-end">
            <button
              id="btn-close-lesson-detail"
              onClick={onClose}
              className="text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 px-3 py-1.5 rounded-md text-xs cursor-pointer transition-colors"
            >
              Back
            </button>
            
            {currentUser.role === 'teacher' && (
              <div className="mt-1">
                {showDeleteConfirm ? (
                  <div className="flex items-center gap-2 bg-red-50 dark:bg-red-950/40 p-1.5 rounded-lg border border-red-200 dark:border-red-900/50">
                    <span className="text-[10px] font-bold text-red-700 dark:text-red-400">Sure?</span>
                    <button
                      id="btn-delete-lesson-yes"
                      onClick={() => onDeleteLesson(lesson.id)}
                      className="text-[9px] font-bold bg-red-655 hover:bg-red-700 text-white px-2 py-0.5 rounded cursor-pointer"
                    >
                      Delete
                    </button>
                    <button
                      id="btn-delete-lesson-no"
                      onClick={() => setShowDeleteConfirm(false)}
                      className="text-[9px] text-slate-500 dark:text-slate-400 hover:underline cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    id="btn-delete-lesson"
                    onClick={() => setShowDeleteConfirm(true)}
                    className="text-[10px] text-red-500 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 cursor-pointer flex items-center gap-1 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* ACTIVE COLLABORATORS PRESENCE SUB-BANNER */}
        <div className="mt-3 flex items-center gap-2 flex-wrap text-[11px] text-slate-505 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800">
          <Users className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
          <span className="font-semibold text-slate-605 dark:text-slate-300">Active Coworkers here:</span>
          {lessonPresences.length === 0 ? (
            <span className="text-slate-400 dark:text-slate-500 italic text-[10px]">Just you viewing this plan now</span>
          ) : (
            <div className="flex items-center gap-1.5 flex-wrap">
              {lessonPresences.map(p => (
                <div
                  key={p.userId}
                  className={`flex items-center gap-1 px-1.5 py-0.5 rounded-full border text-[10px] font-sans ${
                    p.userRole === 'teacher' 
                      ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-300' 
                      : 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-900/60 text-blue-900 dark:text-blue-300'
                  }`}
                >
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                  </span>
                  <span className="font-semibold">{p.userName}</span>
                  <span className="opacity-80">({p.userRole})</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* COMPONENT TAB SELECT BAR */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs select-none">
        <button
          id="tab-btn-plan"
          onClick={() => setActiveTab("plan")}
          className={`px-4 py-3 flex items-center gap-1.5 font-medium border-b-2 cursor-pointer transition-all ${
            activeTab === "plan"
              ? "border-indigo-600 text-indigo-650 dark:text-indigo-450 bg-indigo-50/10 dark:bg-indigo-950/10 font-bold"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          }`}
        >
          <FileText className="w-4 h-4" /> Lesson Outline
        </button>

        <button
          id="tab-btn-checklist"
          onClick={() => setActiveTab("checklist")}
          className={`px-4 py-3 flex items-center gap-1.5 font-medium border-b-2 cursor-pointer transition-all relative ${
            activeTab === "checklist"
              ? "border-indigo-600 text-indigo-655 dark:text-indigo-455 bg-indigo-50/10 dark:bg-indigo-950/10 font-bold"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          }`}
        >
          <CheckSquare className="w-4 h-4" /> Joint Checklists
          {lesson.checklist.filter(i => !i.completed).length > 0 && (
            <span className="ml-1 px-1.5 py-0.1 bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 text-[9px] font-bold rounded-full">
              {lesson.checklist.filter(i => !i.completed).length}
            </span>
          )}
        </button>

        <button
          id="tab-btn-chat"
          onClick={() => setActiveTab("chat")}
          className={`px-4 py-3 flex items-center gap-1.5 font-medium border-b-2 cursor-pointer transition-all relative ${
            activeTab === "chat"
              ? "border-indigo-600 text-indigo-660 dark:text-indigo-460 bg-indigo-50/10 dark:bg-indigo-950/10 font-bold"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          }`}
        >
          <MessageSquare className="w-4 h-4" /> Discussion Chat
          {lesson.comments.length > 0 && (
            <span className="ml-1 px-1.5 py-0.1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[9px] font-bold rounded-full">
              {lesson.comments.length}
            </span>
          )}
        </button>
      </div>

      {/* ACTIVE TAB VIEW CONTROLLER AREA */}
      <div className="flex-1 overflow-y-auto p-4 bg-white dark:bg-slate-900 min-h-[300px]">
        
        {/* TAB 1: OUTLINE PLAN DETAILS */}
        {activeTab === "plan" && (
          <div className="flex flex-col gap-6 max-w-3xl">
            {/* Action text objectives */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1.5">Learning Objectives</h3>
              {isEditingPlanTexts ? (
                <textarea
                  id="edit-objectives-textarea"
                  value={editObjectives}
                  onChange={(e) => setEditObjectives(e.target.value)}
                  placeholder="Review learnings, master objectives..."
                  className="w-full text-xs p-2.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-750 rounded-lg min-h-[80px] font-sans text-slate-800 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              ) : (
                <div className="bg-slate-50 dark:bg-slate-950 rounded-xl p-3 border border-slate-200/65 dark:border-slate-800/80">
                  {lesson.objectives ? (
                    <div className="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
                      {lesson.objectives}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 dark:text-slate-550 italic">No objectives declared yet. Click edit outlines to populate!</p>
                  )}
                </div>
              )}
            </div>

            {/* Timed syllabus progression outline */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Syllabus progression outline</h3>
                {currentUser.role === 'teacher' && !isEditingPlanTexts && (
                  <button
                    id="btn-edit-plan-texts"
                    onClick={() => setIsEditingPlanTexts(true)}
                    className="text-xs text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-305 font-semibold cursor-pointer flex items-center gap-1 transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5" /> Edit Outlines
                  </button>
                )}
              </div>

              {isEditingPlanTexts ? (
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 italic">Use standard headers like ### for timers, and - for bullet points.</span>
                  <textarea
                    id="edit-outline-textarea"
                    value={editOutline}
                    onChange={(e) => setEditOutline(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-750 rounded-lg min-h-[220px] font-mono text-slate-800 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                  <div className="flex justify-end gap-1.5 mt-1">
                    <button
                      id="btn-cancel-plan-edit"
                      onClick={() => setIsEditingPlanTexts(false)}
                      className="px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs rounded-md font-medium text-slate-705 dark:text-slate-300 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      id="btn-save-plan-edit"
                      onClick={handleSavePlanTexts}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs rounded-md font-semibold cursor-pointer"
                    >
                      Save Syllabus Outlines
                    </button>
                  </div>
                </div>
              ) : (
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-white dark:bg-slate-900/50">
                  <div 
                    className="prose prose-slate dark:prose-invert max-w-none prose-sm"
                    dangerouslySetInnerHTML={{ __html: renderSimpleMarkdown(lesson.outline) }}
                  />
                </div>
              )}
            </div>

            {/* List of study materials needed */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1.5">Study Materials Required</h3>
              <div className="flex flex-wrap gap-2 mb-2">
                {lesson.materials.length === 0 ? (
                  <span className="text-xs text-slate-400 dark:text-slate-550 italic">No files or materials attached yet.</span>
                ) : (
                  lesson.materials.map((m, idx) => (
                    <div
                      key={idx}
                      className="px-2.5 py-1 text-xs border border-indigo-100 dark:border-indigo-950/60 bg-indigo-50/20 dark:bg-indigo-950/20 text-slate-700 dark:text-slate-300 rounded-lg flex items-center gap-1"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-indigo-400 dark:text-indigo-505" />
                      <span>{m}</span>
                      {currentUser.role === 'teacher' && (
                        <button
                          onClick={() => handleDeleteMaterial(idx)}
                          className="ml-1 text-slate-400 dark:text-slate-500 hover:text-red-500 dark:hover:text-red-400 focus:outline-none cursor-pointer"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>

              {currentUser.role === 'teacher' && (
                <div className="flex max-w-sm mt-3 gap-1.5">
                  <input
                    id="add-material-input"
                    type="text"
                    placeholder="Add slide URL, textbook, or slider device..."
                    value={newMaterialText}
                    onChange={(e) => setNewMaterialText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddMaterial()}
                    className="flex-1 text-xs px-2.5 py-1.5 border border-slate-205 dark:border-slate-750 bg-white dark:bg-slate-950 rounded-md focus:outline-none focus:border-indigo-500 text-slate-800 dark:text-slate-200"
                  />
                  <button
                    id="btn-add-material"
                    onClick={handleAddMaterial}
                    className="px-3 py-1 bg-slate-900 dark:bg-slate-800 text-white rounded-md text-[11px] font-medium hover:bg-slate-800 dark:hover:bg-slate-700 border border-slate-700/50 cursor-pointer"
                  >
                    Add File
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: JOINT CHECKLISTS TASK PANELS */}
        {activeTab === "checklist" && (
          <div className="max-w-2xl">
            <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Workspace Collaborative Tasks</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4">
              Tick homework exercises, review files, and check off objectives. Changes synchronize in real-time between teacher pings and active students.
            </p>

            <div className="flex flex-col gap-1.5 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-950/40">
              {lesson.checklist.length === 0 ? (
                <div className="p-8 text-center text-slate-400 dark:text-slate-500">
                  <CheckSquare className="w-7 h-7 mx-auto mb-1 opacity-40 text-slate-300 dark:text-slate-700" />
                  <p className="text-xs font-semibold">No cooperative checklists generated.</p>
                </div>
              ) : (
                lesson.checklist.map((item) => {
                  return (
                    <div
                      key={item.id}
                      className={`p-3 bg-white dark:bg-slate-900 hover:bg-slate-50/50 dark:hover:bg-slate-850/40 flex items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 transition-colors last:border-0 ${
                        item.completed ? "opacity-60" : ""
                      }`}
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <button
                          id={`chk-toggle-${item.id}`}
                          onClick={() => handleToggleCheckItem(item.id, item.completed)}
                          className={`w-5 h-5 rounded border flex items-center justify-center cursor-pointer transition-all ${
                            item.completed 
                              ? "bg-emerald-500 border-emerald-600 text-white" 
                              : "border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 hover:border-slate-400"
                          }`}
                        >
                          {item.completed && <Check className="w-3.5 h-3.5" />}
                        </button>
                        
                        <div className="flex-1 min-w-0">
                          <span className={`text-xs block font-medium truncate ${item.completed ? "line-through text-slate-400 dark:text-slate-500 font-normal" : "text-slate-700 dark:text-slate-200"}`}>
                            {item.text}
                          </span>
                          <span className={`text-[9px] font-sans px-1.5 py-0.2 rounded-full font-bold uppercase ${
                            item.role === 'teacher' ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-400' :
                            item.role === 'student' ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-400' :
                            'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                          }`}>
                            Assigned to: {item.role}
                          </span>
                        </div>
                      </div>

                      {currentUser.role === 'teacher' && (
                        <button
                          id={`btn-del-checklist-${item.id}`}
                          onClick={() => handleDeleteChecklistItem(item.id)}
                          className="text-slate-300 dark:text-slate-650 hover:text-red-500 dark:hover:text-red-400 transition-colors p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {/* Quick add checklist row */}
            {currentUser.role === 'teacher' && (
              <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl">
                <h4 className="text-[11px] font-bold text-slate-550 dark:text-slate-400 uppercase mb-2">Create New Task Assignment</h4>
                <div className="flex flex-wrap gap-2">
                  <input
                    id="add-checklist-text-input"
                    type="text"
                    placeholder="Enter activity (review lab notes, pack glasses)..."
                    value={newChecklistText}
                    onChange={(e) => setNewChecklistText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddChecklistItem()}
                    className="flex-1 text-xs px-2.5 py-1.5 border border-slate-200 dark:border-slate-750 rounded-md focus:outline-none focus:border-indigo-500 text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-900"
                  />

                  <select
                    id="add-checklist-role-select"
                    value={newChecklistRole}
                    onChange={(e) => setNewChecklistRole(e.target.value as any)}
                    className="text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-900 rounded-md text-slate-700 dark:text-slate-300 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="both">Both Roles</option>
                    <option value="teacher">Teachers Only</option>
                    <option value="student">Students Only</option>
                  </select>

                  <button
                    id="btn-add-checklist-item"
                    onClick={handleAddChecklistItem}
                    className="px-3.5 py-1.5 bg-slate-900 dark:bg-indigo-650 hover:bg-slate-800 dark:hover:bg-indigo-700 text-white rounded-md text-xs font-semibold cursor-pointer border border-transparent"
                  >
                    Add Task
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: DISCUSSION COMMENTS CHAT */}
        {activeTab === "chat" && (
          <div className="max-w-xl flex flex-col h-[380px]">
            <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1">Classroom Discussion Log</h3>
            <p className="text-[10px] text-slate-450 dark:text-slate-500 mb-3">Live chat and outline queries for this specific lesson</p>

            <div className="flex-1 overflow-y-auto p-3 border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 rounded-xl flex flex-col gap-3 min-h-[220px]">
              {lesson.comments.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-slate-400 dark:text-slate-500 text-center">
                  <MessageSquare className="w-8 h-8 opacity-30 text-slate-300 dark:text-slate-700 mb-1" />
                  <p className="text-xs font-semibold">No comments posted yet.</p>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500">Start the conversation! Type a message below.</p>
                </div>
              ) : (
                lesson.comments.map((comment) => {
                  const isOwn = comment.authorId === currentUser.id;
                  return (
                    <div
                      key={comment.id}
                      className={`flex flex-col max-w-[85%] rounded-2xl p-2.5 text-xs shadow-xs transition-opacity relative ${
                        isOwn 
                          ? "bg-indigo-600 text-white self-end rounded-br-none" 
                          : "bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-100 dark:border-slate-700 self-start rounded-bl-none"
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1 text-[9px] font-sans">
                        <span className={`font-bold uppercase ${isOwn ? "text-indigo-100" : "text-slate-600 dark:text-slate-300"}`}>
                          {comment.authorName}
                        </span>
                        <span className={`px-1 rounded font-bold capitalize ${
                          comment.authorRole === 'teacher' 
                            ? (isOwn ? 'bg-amber-500/20 text-amber-200' : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-400')
                            : (isOwn ? 'bg-blue-500/20 text-blue-200' : 'bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-400')
                        }`}>
                          {comment.authorRole}
                        </span>
                        <span className={`opacity-70 font-mono ml-auto ${isOwn ? "text-indigo-200" : "text-slate-400 dark:text-slate-400"}`}>
                          {new Date(comment.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className={`leading-relaxed whitespace-pre-wrap font-sans ${isOwn ? "text-white" : "text-slate-800 dark:text-slate-100"}`}>
                        {comment.text}
                      </p>
                    </div>
                  );
                })
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Quick send body form */}
            <form onSubmit={handlePostComment} className="flex gap-2 mt-3 select-none">
              <input
                id="type-comment-input"
                type="text"
                placeholder="Type lesson query, worksheet notes, or checkin..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                className="flex-1 text-xs px-3 py-2.5 border border-slate-200 dark:border-slate-850 rounded-lg focus:outline-none focus:border-indigo-500 text-slate-900 dark:text-slate-100 bg-white dark:bg-slate-900"
              />
              <button
                id="btn-send-comment"
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-700 font-semibold text-xs text-white px-4 rounded-lg cursor-pointer transition-colors"
              >
                Send
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}