import { AppUser } from "../types";
import { School, LogOut, ShieldCheck, UserCheck } from "lucide-react";

interface UserSelectionBarProps {
  currentUser: AppUser;
  onSignOut: () => void;
  onlineCount: number;
}

export default function UserSelectionBar({ currentUser, onSignOut, onlineCount }: UserSelectionBarProps) {
  return (
    <div className="bg-slate-900 text-white px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4 text-sm font-sans" id="hub-main-header">
      {/* Academy Logo Brand info */}
      <div className="flex items-center gap-2 select-none">
        <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold shrink-0">
          <School className="w-4.5 h-4.5" />
        </div>
        <div>
          <span className="font-extrabold text-slate-100 tracking-tight block leading-tight">CollabAcademy HUB</span>
          <span className="text-[9px] text-slate-400 block tracking-wide uppercase font-semibold">Active Syllabus Dashboard</span>
        </div>
      </div>

      {/* Authenticated active profile indicator & signout */}
      <div className="flex items-center gap-4 flex-wrap select-none ml-auto">
        <div className="flex items-center gap-2.5 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800" id="user-profile-badge">
          <span className="text-xl" role="img" aria-label="avatar">{currentUser.avatar}</span>
          <div className="flex flex-col">
            <span className="font-semibold text-slate-200 text-xs leading-none mb-0.5">{currentUser.name}</span>
            <div className="flex items-center gap-1">
              {currentUser.role === 'teacher' ? (
                <ShieldCheck className="w-3 h-3 text-amber-500" />
              ) : (
                <UserCheck className="w-3 h-3 text-blue-500" />
              )}
              <span className={`text-[9px] font-bold tracking-wide uppercase ${
                currentUser.role === 'teacher' ? 'text-amber-500' : 'text-blue-400'
              }`}>
                {currentUser.role}
              </span>
            </div>
          </div>
        </div>

        {/* LOGOUT BUTTON */}
        <button
          id="btn-hub-signout"
          onClick={onSignOut}
          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 hover:text-red-400 text-slate-300 rounded-xl border border-slate-700/60 transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
          title="Sign Out of Academy Session"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Sign Out</span>
        </button>
      </div>

      {/* Network Active SSE connections indicator */}
      <div className="flex items-center gap-4 text-xs font-mono select-none">
        <div className="flex items-center gap-1.5 text-emerald-400 bg-emerald-950/40 px-2.5 py-1.5 rounded-xl border border-emerald-900/50">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-[10px] uppercase font-bold tracking-wider font-sans">
            {onlineCount === 1 ? "1 Live Screen" : `${onlineCount} Live Screens`}
          </span>
        </div>
      </div>
    </div>
  );
}
