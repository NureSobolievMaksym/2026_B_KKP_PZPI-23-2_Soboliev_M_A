import React, { useState, useEffect } from "react";
import { NotificationAlert, Lesson } from "../types";
import { Bell, BellRing, Check, Trash2, Clock } from "lucide-react";

interface NotificationCenterProps {
  alerts: NotificationAlert[];
  lessons: Lesson[];
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
  onScheduleTestNotification: (lessonId: string, secondsInFuture: number) => void;
  onClose: () => void;
}

export default function NotificationCenter({
  alerts,
  lessons,
  onMarkRead,
  onClearAll,
  onScheduleTestNotification,
}: NotificationCenterProps) {
  const [selectedLessonId, setSelectedLessonId] = useState<string>("");
  const [testOffsetSeconds, setTestOffsetSeconds] = useState<number>(30); // 30 seconds default

  const unreadCount = alerts.filter(a => !a.isRead).length;

  useEffect(() => {
    // Set first available lesson as default in selector
    const scheduledLessons = lessons.filter(l => l.status === "scheduled" || l.status === "draft");
    if (scheduledLessons.length > 0 && !selectedLessonId) {
      setSelectedLessonId(scheduledLessons[0].id);
    }
  }, [lessons, selectedLessonId]);

  // Trigger sound effect when alert counts increase
  useEffect(() => {
    if (alerts.length > 0 && alerts.some(a => !a.isRead)) {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        
        oscillator.type = "sine";
        oscillator.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        oscillator.frequency.setValueAtTime(880, audioCtx.currentTime + 0.1); // A5
        
        gainNode.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);
        
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.start();
        oscillator.stop(audioCtx.currentTime + 0.4);
      } catch (err) {
        // Safe fail if audio context blocked or unsuported
      }
    }
  }, [alerts.length]);

  const handleTestCreate = () => {
    if (!selectedLessonId) return;
    onScheduleTestNotification(selectedLessonId, testOffsetSeconds);
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-xl shadow-lg border border-slate-200 dark:border-slate-800 overflow-hidden text-slate-850 dark:text-slate-100" id="notification-panel">
      {/* Visual Header */}
      <div className="bg-slate-950 text-white px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {unreadCount > 0 ? (
            <BellRing className="w-5 h-5 text-amber-400 animate-bounce" />
          ) : (
            <Bell className="w-5 h-5 text-slate-400" />
          )}
          <div>
            <h3 className="font-bold text-sm tracking-tight">Notification Center</h3>
            <p className="text-[10px] text-slate-400">Automated learning schedules & triggers</p>
          </div>
        </div>
        
        {unreadCount > 0 && (
          <span className="bg-amber-500 text-slate-950 text-[10px] font-bold px-2 py-0.5 rounded-full font-mono animate-pulse">
            {unreadCount} NEW
          </span>
        )}
      </div>

      {/* AUTOMATED TRIGGER TESTER BOX */}
      <div className="p-3 bg-indigo-50/50 dark:bg-slate-950/40 border-b border-indigo-100 dark:border-indigo-950/60 flex flex-col gap-2">
        <div className="flex items-center gap-1.5 text-indigo-900 dark:text-indigo-400 font-semibold text-xs">
          <Clock className="w-4 h-4 text-indigo-500" />
          <span>Test Automated Alerts Scheduler</span>
        </div>
        <p className="text-[10px] text-indigo-700 dark:text-indigo-300 leading-relaxed">
          Simulate background automated reminders. Choose a lesson and queue an alert. The system will count down and trigger a real-time chime.
        </p>

        <div className="flex gap-1.5 mt-1">
          <select
            id="test-lesson-select"
            value={selectedLessonId}
            onChange={(e) => setSelectedLessonId(e.target.value)}
            className="flex-1 text-[11px] px-2 py-1.5 border border-indigo-200 dark:border-slate-750 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
          >
            <option value="" disabled className="dark:bg-slate-900">Select Lesson</option>
            {lessons.map(l => (
              <option key={l.id} value={l.id} className="dark:bg-slate-900">{l.title}</option>
            ))}
          </select>

          <select
            id="test-time-select"
            value={testOffsetSeconds}
            onChange={(e) => setTestOffsetSeconds(Number(e.target.value))}
            className="w-24 text-[11px] px-2 py-1.5 border border-indigo-200 dark:border-slate-750 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
          >
            <option value={10} className="dark:bg-slate-900">in 10s</option>
            <option value={30} className="dark:bg-slate-900">in 30s</option>
            <option value={60} className="dark:bg-slate-900">in 1m</option>
            <option value={300} className="dark:bg-slate-900">in 5m</option>
          </select>

          <button
            id="btn-trigger-test-alert"
            onClick={handleTestCreate}
            disabled={!selectedLessonId}
            className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 dark:disabled:bg-slate-800 text-white font-medium text-[11px] px-3 rounded cursor-pointer transition-colors whitespace-nowrap"
          >
            Queue
          </button>
        </div>
      </div>

      {/* TRIGGERS HISTORY LIST */}
      <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2 bg-slate-50 dark:bg-slate-950/20 min-h-[160px]">
        {alerts.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 py-12 text-center">
            <Bell className="w-8 h-8 text-slate-200 dark:text-slate-805 mb-1" />
            <p className="text-xs font-semibold">No alerts triggered yet</p>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 max-w-[180px] mt-0.5">
              Notifications log automatically when scheduled lessons approach their start times.
            </p>
          </div>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.id}
              id={`alert-card-${alert.id}`}
              className={`p-2.5 rounded-lg border transition-all duration-200 relative ${
                alert.isRead
                  ? "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-75"
                  : "bg-indigo-50/50 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-900 ring-1 ring-indigo-100 dark:ring-indigo-950 shadow-xs"
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 dark:bg-indigo-400 animate-pulse" />
                    <span className="text-[10px] font-bold text-indigo-805 dark:text-indigo-400 uppercase tracking-wide">
                      Remind Alert
                    </span>
                    <span className="text-[9px] text-slate-400 dark:text-slate-500 font-mono ml-auto">
                      {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight">
                    {alert.lessonTitle}
                  </h4>
                  <p className="text-[10px] text-slate-605 dark:text-slate-400 mt-1 leading-snug">
                    {alert.message}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 mt-2 pt-1.5 border-t border-slate-105/50 dark:border-slate-800/50">
                {!alert.isRead && (
                  <button
                    id={`btn-read-${alert.id}`}
                    onClick={() => onMarkRead(alert.id)}
                    className="p-1 hover:bg-indigo-100 dark:hover:bg-indigo-950/30 rounded text-indigo-700 dark:text-indigo-400 text-[10px] font-medium flex items-center gap-1 cursor-pointer"
                    title="Mark as Seen"
                  >
                    <Check className="w-3 h-3" /> Seen
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* BOTTOM ACTION BUTTONS */}
      {alerts.length > 0 && (
        <div className="p-2 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex justify-between items-center text-xs">
          <button
            id="btn-clear-alerts"
            onClick={onClearAll}
            className="text-slate-500 dark:text-slate-400 hover:text-red-650 dark:hover:text-red-400 p-1 rounded font-medium flex items-center gap-1 cursor-pointer transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear Logs
          </button>
          
          <span className="text-[9px] text-slate-400 dark:text-slate-500 font-mono">
            {alerts.length} Total Alerts Logged
          </span>
        </div>
      )}
    </div>
  );
}
