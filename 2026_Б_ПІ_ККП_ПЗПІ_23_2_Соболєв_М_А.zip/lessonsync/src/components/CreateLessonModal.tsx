import React, { useState, useEffect } from "react";
import { AppUser } from "../types";
import { X, Calendar, BookOpen, Clock, Users, ShieldAlert, GraduationCap } from "lucide-react";

interface CreateLessonModalProps {
  isOpen: boolean;
  dateStr: string;
  currentUser: AppUser;
  onClose: () => void;
  onSubmit: (data: {
    title: string;
    subject: string;
    gradeLevel: string;
    duration: number;
    startTime: string;
    endTime: string;
    status: 'draft' | 'scheduled' | 'active' | 'completed';
    students: string[];
  }) => Promise<void>;
}

export default function CreateLessonModal({
  isOpen,
  dateStr,
  currentUser,
  onClose,
  onSubmit
}: CreateLessonModalProps) {
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("Science");
  const [gradeLevel, setGradeLevel] = useState("Grade 11");
  const [duration, setDuration] = useState(60);
  const [startTime, setStartTime] = useState("09:00");
  const [status, setStatus] = useState<'draft' | 'scheduled' | 'active' | 'completed'>("draft");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [studentsList, setStudentsList] = useState<{ id: string; name: string; avatar: string }[]>([]);
  const [selectedStudentId, setSelectedStudentId] = useState("");

  // Fetch registered students when modal opens
  useEffect(() => {
    if (isOpen) {
      setTitle("");
      setSubject("Science");
      setDuration(60);
      setStartTime("09:00");
      setStatus("draft");
      setIsSubmitting(false);

      fetch("/api/users/students")
        .then((res) => res.json())
        .then((data) => {
          setStudentsList(data);
          if (data.length > 0) {
            setSelectedStudentId(data[0].id);
            setGradeLevel(data[0].name);
          } else {
            setSelectedStudentId("");
            setGradeLevel("No Student");
          }
        })
        .catch((err) => console.error("Error fetching students list:", err));
    }
  }, [isOpen, dateStr]);

  if (!isOpen) return null;

  const isTeacher = currentUser.role === "teacher";

  const handleStudentChange = (studentId: string) => {
    setSelectedStudentId(studentId);
    const chosen = studentsList.find((s) => s.id === studentId);
    if (chosen) {
      setGradeLevel(chosen.name);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || isSubmitting) return;

    setIsSubmitting(true);

    // Calculate end time based on start time + duration
    let endTime = "10:00";
    try {
      const [h, m] = startTime.split(":").map(Number);
      const totalMinutes = h * 60 + m + Number(duration);
      const endH = Math.floor(totalMinutes / 60) % 24;
      const endM = totalMinutes % 60;
      endTime = `${String(endH).padStart(2, "0")}:${String(endM).padStart(2, "0")}`;
    } catch (err) {
      // fallback
    }

    try {
      await onSubmit({
        title: title.trim(),
        subject,
        gradeLevel,
        duration: Number(duration),
        startTime,
        endTime,
        status,
        students: selectedStudentId ? [selectedStudentId] : []
      });
      onClose();
    } catch (err) {
      console.error("Failed to submit and create lesson:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs select-none" id="create-lesson-modal-overlay">
      <div 
        className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-150 dark:border-slate-800 max-w-md w-full overflow-hidden animate-slide-in text-slate-850 dark:text-slate-100"
        id="create-lesson-modal-card"
      >
        {/* Modal Header */}
        <div className="px-5 py-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-200/80 dark:border-slate-850 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-500" />
            <h3 className="font-extrabold text-sm tracking-tight text-slate-905 dark:text-slate-100">
              {isTeacher ? "Schedule New Lesson Plan" : "Teacher Privileges Required"}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5">
          {!isTeacher ? (
            /* STUDENT VIEW: Friendly restriction alert */
            <div className="text-center py-4">
              <div className="w-12 h-12 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-full flex items-center justify-center mx-auto mb-3">
                <ShieldAlert className="w-6 h-6 text-amber-600 dark:text-amber-400" />
              </div>
              <h4 className="font-bold text-sm text-slate-850 dark:text-slate-200 mb-1">
                Access Denied for Day-Scheduling
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed max-w-sm mx-auto mb-4">
                You are currently logged in as a student (<strong>{currentUser.name}</strong>). Only teacher profiles possess full privileges to write new syllabi, declare objective targets, or schedule lessons.
              </p>
              
              <div className="bg-indigo-50/50 dark:bg-slate-950/60 rounded-xl p-3 border border-indigo-100 dark:border-slate-800 text-left mb-6">
                <div className="flex items-start gap-2 text-indigo-900 dark:text-indigo-400 text-xs">
                  <GraduationCap className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Test this action!</span> Switch roles using the active profile selector dropdown in the top bar (e.g. choose <strong>Ms. Cooper</strong> or <strong>Mr. Harrison</strong>) to gain immediate creation access.
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white font-semibold text-xs rounded-xl cursor-pointer transition-colors"
                >
                  Understood
                </button>
              </div>
            </div>
          ) : (
            /* TEACHER VIEW: Interactive Lesson creation Form */
            <form onSubmit={handleFormSubmit} className="flex flex-col gap-4">
              <div className="text-xs bg-slate-50 dark:bg-slate-950 p-2.5 rounded-lg border border-slate-150 dark:border-slate-850 text-slate-505 dark:text-slate-400 flex items-center gap-1.5 mb-1 font-medium">
                <Calendar className="w-4 h-4 text-indigo-400" />
                <span>Scheduling for Date:</span>
                <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{dateStr}</span>
              </div>

              {/* Title Input */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                  Lesson Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Advanced Astrophysics Seminar"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-lg focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-medium"
                  autoFocus
                />
              </div>

              {/* Subject Input */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                    Subject Area
                  </label>
                  <select
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full text-xs px-2.5 py-2 border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="Science">Science</option>
                    <option value="Computer Science">Computer Science</option>
                    <option value="Secondary Humanities">Secondary Humanities</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="General Study">General Study</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                    Assigned Pupil (Student)
                  </label>
                  <select
                    value={selectedStudentId}
                    onChange={(e) => handleStudentChange(e.target.value)}
                    className="w-full text-xs px-2.5 py-2 border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 cursor-pointer font-medium"
                  >
                    {studentsList.map((stud) => (
                      <option key={stud.id} value={stud.id}>
                        {stud.avatar} {stud.name}
                      </option>
                    ))}
                    {studentsList.length === 0 && (
                      <option value="">No students available</option>
                    )}
                  </select>
                </div>
              </div>

              {/* Start Time & Duration */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                    Start Time
                  </label>
                  <div className="relative">
                    <Clock className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5 pointer-events-none" />
                    <input
                      type="time"
                      required
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="w-full text-xs pl-8 pr-2.5 py-2 border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-lg focus:outline-none focus:border-indigo-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                    Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    required
                    min={10}
                    max={480}
                    value={duration}
                    onChange={(e) => setDuration(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-lg focus:outline-none focus:border-indigo-500 font-mono font-medium"
                  />
                </div>
              </div>

              {/* Status Select */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                  Initial Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full text-xs px-2.5 py-2 border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="draft">Draft</option>
                  <option value="scheduled">Scheduled</option>
                </select>
              </div>

              <div className="flex justify-end gap-2.5 mt-4 pt-4 border-t border-slate-150 dark:border-slate-850">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-xs rounded-xl cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!title.trim() || isSubmitting}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-350 text-white font-semibold text-xs rounded-xl cursor-pointer transition-all shadow-sm flex items-center gap-1"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Schedule Lesson"
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
