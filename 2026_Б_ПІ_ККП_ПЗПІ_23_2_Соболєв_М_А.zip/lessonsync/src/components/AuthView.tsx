import React, { useState } from "react";
import { AppUser } from "../types";
import { Lock, User, Sparkles, School, ChevronRight, CheckCircle2, AlertCircle, Eye, EyeOff } from "lucide-react";

interface AuthViewProps {
  onLoginSuccess: (user: AppUser) => void;
}

export default function AuthView({ onLoginSuccess }: AuthViewProps) {
  const [isLoginMode, setIsLoginMode] = useState<boolean>(true);
  
  // Form States
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<'teacher' | 'student'>("teacher");
  const [avatar, setAvatar] = useState("👩‍🏫");
  const [showPassword, setShowPassword] = useState(false);
  
  // Feedback states
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Avatar choices
  const teacherAvatars = ["👩‍🏫", "👨‍🏫", "🧑‍🏫", "👩‍🔬", "👨‍🎨"];
  const studentAvatars = ["👩‍🎓", "👨‍🎓", "🧑‍🎓", "🧑‍💻", "🎒", "🦊", "🌟"];

  const handleModeSwitch = () => {
    setIsLoginMode(!isLoginMode);
    setErrorMessage("");
    setSuccessMessage("");
    setUsername("");
    setPassword("");
    setName("");
    // set default matching avatar
    setAvatar(role === "teacher" ? "👩‍🏫" : "👩‍🎓");
  };

  const handleRoleChange = (newRole: 'teacher' | 'student') => {
    setRole(newRole);
    setAvatar(newRole === "teacher" ? "👩‍🏫" : "👩‍🎓");
  };

  // Pre-loaded Fast Login triggers for sandbox testing
  const handleQuickLogin = (uname: string) => {
    setUsername(uname);
    setPassword("123");
    setErrorMessage("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");
    setIsLoading(true);

    if (!username.trim() || !password.trim()) {
      setErrorMessage("Please enter both username and password");
      setIsLoading(false);
      return;
    }

    if (!isLoginMode && !name.trim()) {
      setErrorMessage("Please enter your display name");
      setIsLoading(false);
      return;
    }

    try {
      if (isLoginMode) {
        // Sign-in
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username: username.trim(),
            password: password.trim()
          })
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "Authentication failed");
        }

        onLoginSuccess(data.user);
      } else {
        // Registration
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username: username.trim(),
            password: password.trim(),
            name: name.trim(),
            role,
            avatar
          })
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "Failed to create profile");
        }

        setSuccessMessage("Account created successfully! Switching to login...");
        setTimeout(() => {
          setIsLoginMode(true);
          setPassword("");
          setSuccessMessage("");
          setIsLoading(false);
        }, 1500);
      }
    } catch (err: any) {
      setErrorMessage(err.message || "An unexpected issue occurred");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden font-sans select-none" id="auth-container">
      {/* Visual background ambient details */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-900/10 rounded-full filter blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-emerald-900/5 rounded-full filter blur-3xl pointer-events-none" />
      
      <div className="w-full max-w-md bg-slate-900/90 border border-slate-800/80 rounded-2xl p-6 md:p-8 shadow-2xl relative z-10 backdrop-blur-md">
        {/* Hub logo header */}
        <div className="flex flex-col items-center text-center pb-6 border-b border-slate-800/60 mb-6">
          <div className="w-12 h-12 bg-indigo-600/10 border border-indigo-500/20 rounded-xl flex items-center justify-center text-indigo-400 mb-3 shadow-inner">
            <School className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-extrabold text-slate-100 tracking-tight">CollabAcademy HUB</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-[280px]">
            Collaborative Lesson Planning & Syllabus Scheduling system
          </p>
        </div>

        {/* Dynamic header mode */}
        <div className="text-center mb-6">
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800/50 mb-4 text-xs font-semibold">
            <button
              id="auth-mode-login"
              onClick={() => { if (!isLoginMode) handleModeSwitch(); }}
              className={`flex-1 py-2 rounded-lg transition-all duration-150 cursor-pointer ${
                isLoginMode
                  ? "bg-indigo-600 text-white font-bold"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Sign In
            </button>
            <button
              id="auth-mode-register"
              onClick={() => { if (isLoginMode) handleModeSwitch(); }}
              className={`flex-1 py-2 rounded-lg transition-all duration-150 cursor-pointer ${
                !isLoginMode
                  ? "bg-indigo-600 text-white font-bold"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Create Account
            </button>
          </div>
        </div>

        {/* Message banners */}
        {errorMessage && (
          <div className="mb-4 p-3 border border-red-500/25 bg-red-950/20 text-red-400 rounded-xl text-xs flex gap-2 items-center" id="auth-error-banner">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 border border-emerald-500/25 bg-emerald-950/20 text-emerald-400 rounded-xl text-xs flex gap-2 items-center animate-pulse" id="auth-success-banner">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* USERNAME FIELD */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Username</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                <User className="w-3.5 h-3.5" />
              </span>
              <input
                id="auth-username-input"
                type="text"
                placeholder="e.g. cooper, sophia..."
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={isLoading}
                className="w-full text-xs pl-8 pr-3 py-2.5 bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl text-slate-100 focus:outline-none transition-all placeholder:text-slate-600"
              />
            </div>
          </div>

          {/* PASSWORD FIELD */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Password</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                <Lock className="w-3.5 h-3.5" />
              </span>
              <input
                id="auth-password-input"
                type={showPassword ? "text" : "password"}
                placeholder="••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
                className="w-full text-xs pl-8 pr-10 py-2.5 bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl text-slate-100 focus:outline-none transition-all placeholder:text-slate-600"
              />
              <button
                id="btn-toggle-password"
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* REGISTER EXTRA FIELDS */}
          {!isLoginMode && (
            <div className="flex flex-col gap-4 border-t border-slate-800/40 pt-4 animate-fade-in">
              {/* DISPLAY NAME */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Full Display Name</label>
                <input
                  id="auth-name-input"
                  type="text"
                  placeholder="e.g. Ms. Amelia Cooper"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  disabled={isLoading}
                  className="w-full text-xs px-3 py-2.5 bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl text-slate-100 focus:outline-none transition-all placeholder:text-slate-700"
                />
              </div>

              {/* ROLE SELECTION */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Academy Role</label>
                <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                  <button
                    id="role-teach-btn"
                    type="button"
                    onClick={() => handleRoleChange("teacher")}
                    className={`py-2 rounded-xl border flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      role === "teacher"
                        ? "bg-indigo-950/40 border-indigo-500/50 text-indigo-300 ring-1 ring-indigo-900"
                        : "bg-slate-950/40 border-slate-800 text-slate-400"
                    }`}
                  >
                    <span>👩‍🏫</span>
                    <span>Teacher</span>
                  </button>
                  <button
                    id="role-stud-btn"
                    type="button"
                    onClick={() => handleRoleChange("student")}
                    className={`py-2 rounded-xl border flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      role === "student"
                        ? "bg-indigo-950/40 border-indigo-500/50 text-indigo-300 ring-1 ring-indigo-900"
                        : "bg-slate-950/40 border-slate-800 text-slate-400"
                    }`}
                  >
                    <span>👩‍🎓</span>
                    <span>Student</span>
                  </button>
                </div>
              </div>

              {/* AVATAR CHOOSER */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Pick Avatar Icon</label>
                <div className="flex gap-2 flex-wrap bg-slate-950 p-2 rounded-xl border border-slate-800/60 justify-center">
                  {(role === "teacher" ? teacherAvatars : studentAvatars).map((av) => (
                    <button
                      key={av}
                      type="button"
                      onClick={() => setAvatar(av)}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm border-2 cursor-pointer transition-all ${
                        avatar === av
                          ? "bg-indigo-600/20 border-indigo-500"
                          : "border-transparent bg-slate-900 hover:bg-slate-800"
                      }`}
                    >
                      {av}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SUBMIT BUTTON */}
          <button
            id="btn-auth-submit"
            type="submit"
            disabled={isLoading}
            className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-800 text-white text-xs font-bold py-3 px-4 rounded-xl shadow-md cursor-pointer transition-all mt-2.5 flex items-center justify-center gap-1.5"
          >
            {isLoading ? (
              <span className="w-4 h-4 rounded-full border-2 border-slate-400 border-t-white animate-spin" />
            ) : (
              <>
                <span>{isLoginMode ? "Secure Log In" : "Register and Open Account"}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </form>

        {/* DEMO SHORTCUT PANEL - IDEAL FOR MULTI-USER SANDBOX WRITING */}
        {isLoginMode && (
          <div className="mt-6 pt-5 border-t border-slate-800/40 flex flex-col gap-2.5" id="fast-login-sandbox">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Fast Sandbox Identities (Click to Load)</span>
              <span className="text-[8px] bg-slate-800 text-slate-400 px-1.5 py-0.2 rounded font-mono">123</span>
            </div>
            
            <div className="grid grid-cols-2 gap-2 text-[11px] font-semibold text-slate-300">
              <button
                id="quick-login-cooper"
                onClick={() => handleQuickLogin("cooper")}
                className="p-1.5 bg-slate-950/40 border border-slate-800 hover:border-slate-700 rounded-lg flex items-center gap-1.5 cursor-pointer text-left hover:text-white"
              >
                <span>👩‍🏫</span>
                <div className="truncate">
                  <p className="font-bold leading-none text-slate-300 text-[10px]">Ms. Cooper</p>
                  <span className="text-[8px] opacity-65 font-mono">cooper</span>
                </div>
              </button>

              <button
                id="quick-login-harrison"
                onClick={() => handleQuickLogin("harrison")}
                className="p-1.5 bg-slate-950/40 border border-slate-800 hover:border-slate-700 rounded-lg flex items-center gap-1.5 cursor-pointer text-left hover:text-white"
              >
                <span>👨‍🏫</span>
                <div className="truncate">
                  <p className="font-bold leading-none text-slate-300 text-[10px]">Mr. Harrison</p>
                  <span className="text-[8px] opacity-65 font-mono">harrison</span>
                </div>
              </button>

              <button
                id="quick-login-sophia"
                onClick={() => handleQuickLogin("sophia")}
                className="p-1.5 bg-slate-950/40 border border-slate-800 hover:border-slate-700 rounded-lg flex items-center gap-1.5 cursor-pointer text-left hover:text-white"
              >
                <span>👩‍🎓</span>
                <div className="truncate">
                  <p className="font-bold leading-none text-slate-300 text-[10px]">Sophia</p>
                  <span className="text-[8px] opacity-65 font-mono">sophia</span>
                </div>
              </button>

              <button
                id="quick-login-liam"
                onClick={() => handleQuickLogin("liam")}
                className="p-1.5 bg-slate-950/40 border border-slate-800 hover:border-slate-700 rounded-lg flex items-center gap-1.5 cursor-pointer text-left hover:text-white"
              >
                <span>👨‍🎓</span>
                <div className="truncate">
                  <p className="font-bold leading-none text-slate-300 text-[10px]">Liam</p>
                  <span className="text-[8px] opacity-65 font-mono">liam</span>
                </div>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
