import React, { useState } from "react";
import { Lesson } from "../types";
import { Calendar, ChevronLeft, ChevronRight, Filter, Search, Plus, BookOpen, Clock } from "lucide-react";

interface CalendarViewProps {
  lessons: Lesson[];
  onSelectLesson: (lesson: Lesson) => void;
  onCreateLesson: (dateStr: string) => void;
  isTeacher: boolean;
}

const SUBJECT_COLORS: Record<string, { bg: string, text: string, border: string, dot: string }> = {
  "Science": { bg: "bg-emerald-50 dark:bg-emerald-950/20", text: "text-emerald-700 dark:text-emerald-400", border: "border-emerald-250 dark:border-emerald-900/50", dot: "bg-emerald-500" },
  "Computer Science": { bg: "bg-indigo-50 dark:bg-indigo-950/20", text: "text-indigo-700 dark:text-indigo-400", border: "border-indigo-250 dark:border-indigo-900/50", dot: "bg-indigo-500" },
  "Secondary Humanities": { bg: "bg-amber-50 dark:bg-amber-950/20", text: "text-amber-700 dark:text-amber-400", border: "border-amber-250 dark:border-amber-900/50", dot: "bg-amber-500" },
  "Mathematics": { bg: "bg-purple-50 dark:bg-purple-950/20", text: "text-purple-700 dark:text-purple-400", border: "border-purple-250 dark:border-purple-900/50", dot: "bg-purple-500" },
  "General Study": { bg: "bg-slate-50 dark:bg-slate-800/40", text: "text-slate-700 dark:text-slate-300", border: "border-slate-250 dark:border-slate-700/50", dot: "bg-slate-500" }
};

const getSubjectStyles = (subject: string) => {
  return SUBJECT_COLORS[subject] || { bg: "bg-slate-50 dark:bg-slate-800/40", text: "text-slate-700 dark:text-slate-300", border: "border-slate-200 dark:border-slate-750", dot: "bg-slate-500" };
};

export default function CalendarView({ lessons, onSelectLesson, onCreateLesson, isTeacher }: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [viewType, setViewType] = useState<"month" | "week" | "day">("month");
  const [subjectFilter, setSubjectFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // Navigation handlers
  const handlePrev = () => {
    const newDate = new Date(currentDate);
    if (viewType === "month") {
      newDate.setMonth(newDate.getMonth() - 1);
    } else if (viewType === "week") {
      newDate.setDate(newDate.getDate() - 7);
    } else {
      newDate.setDate(newDate.getDate() - 1);
    }
    setCurrentDate(newDate);
  };

  const handleNext = () => {
    const newDate = new Date(currentDate);
    if (viewType === "month") {
      newDate.setMonth(newDate.getMonth() + 1);
    } else if (viewType === "week") {
      newDate.setDate(newDate.getDate() + 7);
    } else {
      newDate.setDate(newDate.getDate() + 1);
    }
    setCurrentDate(newDate);
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  // Extract unique subjects
  const subjects = ["all", ...Array.from(new Set(lessons.map((l) => l.subject)))];

  // Filter and search lessons
  const filteredLessons = lessons.filter((lesson) => {
    const matchesSubject = subjectFilter === "all" || lesson.subject === subjectFilter;
    const matchesSearch =
      lesson.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lesson.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lesson.gradeLevel.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  // Calculate Month Calendar Matrix
  const getMonthMatrix = () => {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const numDays = lastDay.getDate();
    const startOffset = firstDay.getDay(); // 0 is Sunday, etc.

    const matrix: (Date | null)[] = [];

    // Prepopulate empty offsets from previous month
    const prevMonthLast = new Date(year, month, 0).getDate();
    for (let i = startOffset - 1; i >= 0; i--) {
      matrix.push(new Date(year, month - 1, prevMonthLast - i));
    }

    // Populate active days
    for (let d = 1; d <= numDays; d++) {
      matrix.push(new Date(year, month, d));
    }

    // Trailing empty slots to make full grids (multiples of 7)
    const totalCells = Math.ceil(matrix.length / 7) * 7;
    const nextDaysNeeded = totalCells - matrix.length;
    for (let d = 1; d <= nextDaysNeeded; d++) {
      matrix.push(new Date(year, month + 1, d));
    }

    return matrix;
  };

  // Get active week days
  const getWeekDays = () => {
    const dayOfWeek = currentDate.getDay(); // 0-6
    const sunday = new Date(currentDate);
    sunday.setDate(currentDate.getDate() - dayOfWeek);

    const week: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(sunday);
      d.setDate(sunday.getDate() + i);
      week.push(d);
    }
    return week;
  };

  // Format Helper for headings
  const getHeaderLabel = () => {
    if (viewType === "month") {
      return currentDate.toLocaleDateString("en-US", { month: "long", year: "numeric" });
    } else if (viewType === "week") {
      const weekDays = getWeekDays();
      const start = weekDays[0].toLocaleDateString("en-US", { month: "short", day: "numeric" });
      const end = weekDays[6].toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
      return `${start} – ${end}`;
    } else {
      return currentDate.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" });
    }
  };

  // Find lessons scheduled for specific date 'YYYY-MM-DD'
  const getLessonsForDate = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`; 

    return filteredLessons.filter((l) => l.date === dateStr);
  };

  const formatLocalDate = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  const isCurrentMonth = (date: Date) => {
    return date.getMonth() === month && date.getFullYear() === year;
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-xl shadow-xs border border-slate-200 dark:border-slate-800 overflow-hidden" id="calendar-root">
      {/* Search and Filters Header */}
      <div className="p-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-slate-500 dark:text-slate-400" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Academic Scheduler</h2>
        </div>

        <div className="flex items-center gap-2 flex-wrap flex-1 max-w-xl justify-end">
          {/* Custom Search bar */}
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="w-4 h-4 text-slate-400 dark:text-slate-550 absolute left-3 top-2.5" />
            <input
              id="search-lessons-input"
              type="text"
              placeholder="Search subject, grade, core terms..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all"
            />
          </div>

          {/* Filtering dropdown */}
          <div className="relative">
            <select
              id="subject-filter-select"
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="appearance-none text-xs pl-8 pr-8 py-2 border border-slate-200 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-medium focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              <option value="all">All Subjects</option>
              {subjects.filter(s => s !== "all").map((sub) => (
                <option key={sub} value={sub}>{sub}</option>
              ))}
            </select>
            <Filter className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 absolute left-3 top-3 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Calendar Navigation Controller */}
      <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900">
        <div className="flex items-center gap-2">
          <button
            id="btn-calendar-prev"
            onClick={handlePrev}
            className="p-1.5 border border-slate-200 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer transition-colors"
          >
            <ChevronLeft className="w-4 h-4 text-slate-600 dark:text-slate-400" />
          </button>
          <span className="text-sm font-semibold text-slate-800 dark:text-slate-200 font-mono w-44 text-center">
            {getHeaderLabel()}
          </span>
          <button
            id="btn-calendar-next"
            onClick={handleNext}
            className="p-1.5 border border-slate-200 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer transition-colors"
          >
            <ChevronRight className="w-4 h-4 text-slate-600 dark:text-slate-400" />
          </button>
          <button
            id="btn-calendar-today"
            onClick={handleToday}
            className="px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 rounded-md text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer text-slate-700 dark:text-slate-300 ml-1"
          >
            Today
          </button>
        </div>

        {/* View Switches */}
        <div className="flex bg-slate-100 dark:bg-slate-950 p-0.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs">
          {(["month", "week", "day"] as const).map((view) => (
            <button
              key={view}
              id={`btn-view-${view}`}
              onClick={() => setViewType(view)}
              className={`px-3 py-1.5 rounded-md font-medium capitalize cursor-pointer transition-all ${
                viewType === view
                  ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs"
                  : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
              }`}
            >
              {view}
            </button>
          ))}
        </div>
      </div>

      {/* RENDER VIEW SCHEMES */}
      <div className="flex-1 overflow-auto bg-slate-50/50 dark:bg-slate-950/20 p-2 min-h-[460px]">
        {/* VIEW: MONTH */}
        {viewType === "month" && (
          <div className="grid grid-cols-7 gap-1 h-full min-w-[700px]">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((dayName) => (
              <div key={dayName} className="text-center font-semibold text-xs text-slate-400 dark:text-slate-500 py-1 uppercase">
                {dayName}
              </div>
            ))}

            {getMonthMatrix().map((date, index) => {
              if (!date) return <div key={index} className="bg-slate-50/50 dark:bg-slate-950/20 rounded-lg min-h-[90px] border border-dashed border-slate-100 dark:border-slate-850" />;
              
              const dayLessons = getLessonsForDate(date);
              const isCurr = isCurrentMonth(date);
              const isTod = isToday(date);
              const dateStr = formatLocalDate(date);

              return (
                <div
                  key={index}
                  id={`cell-date-${dateStr}`}
                  onClick={() => onCreateLesson(dateStr)}
                  className={`bg-white dark:bg-slate-900 rounded-lg border min-h-[100px] p-1 flex flex-col group transition-all duration-150 cursor-pointer hover:border-slate-300 dark:hover:border-slate-700 relative ${
                    isCurr ? "border-slate-150 dark:border-slate-800" : "border-slate-100 dark:border-slate-850/50 opacity-40 bg-slate-50/20 dark:bg-slate-950/20"
                  } ${isTod ? "ring-2 ring-indigo-500 ring-offset-1 bg-indigo-50/5 dark:bg-indigo-950/20" : ""}`}
                >
                  <div className="flex items-center justify-between pb-1">
                    <span className={`text-xs font-mono font-medium rounded-full w-5 h-5 flex items-center justify-center ${
                      isTod ? "bg-indigo-600 text-white font-bold" : "text-slate-700 dark:text-slate-300"
                    }`}>
                      {date.getDate()}
                    </span>

                    {/* Quick Create Indicator for teachers */}
                    {isTeacher && isCurr && (
                      <Plus className="w-3 h-3 text-slate-300 dark:text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                    )}
                  </div>

                  {/* List of lesson dots / tiny badges */}
                  <div className="flex-1 flex flex-col gap-1 overflow-y-auto max-h-[85px] scrollbar-thin">
                    {dayLessons.map((lesson) => {
                      const style = getSubjectStyles(lesson.subject);
                      return (
                        <div
                          key={lesson.id}
                          id={`badge-lesson-${lesson.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectLesson(lesson);
                          }}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-medium border ${style.bg} ${style.text} ${style.border} truncate hover:translate-x-0.5 hover:shadow-xs transition-all flex items-center gap-1`}
                          title={`${lesson.title} (${lesson.startTime})`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${style.dot}`} />
                          <span className="truncate flex-1">{lesson.title}</span>
                          <span className="text-[8px] font-mono opacity-80">{lesson.startTime}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW: WEEK */}
        {viewType === "week" && (
          <div className="grid grid-cols-7 gap-2 h-full min-w-[700px]">
            {getWeekDays().map((dayDate, index) => {
              const dayLessons = getLessonsForDate(dayDate);
              const isTd = isToday(dayDate);
              const dateStr = formatLocalDate(dayDate);

              return (
                <div
                  key={index}
                  className={`bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-2 min-h-[380px] flex flex-col ${
                    isTd ? "ring-2 ring-indigo-500 ring-offset-1 bg-indigo-50/5 dark:bg-indigo-950/20" : ""
                  }`}
                >
                  <div className="text-center pb-2 border-b border-slate-100 dark:border-slate-800 flex flex-col items-center">
                    <span className="text-xs text-slate-400 dark:text-slate-500 font-medium uppercase font-sans">
                      {dayDate.toLocaleDateString("en-US", { weekday: "short" })}
                    </span>
                    <span className={`text-base font-semibold font-mono w-7 h-7 flex items-center justify-center rounded-full ${
                      isTd ? "bg-indigo-600 text-white" : "text-slate-700 dark:text-slate-300"
                    }`}>
                      {dayDate.getDate()}
                    </span>
                  </div>

                  <div className="flex-1 flex flex-col gap-2 pt-2 overflow-y-auto">
                    {dayLessons.length === 0 ? (
                      <div className="hidden sm:flex flex-col items-center justify-center h-full text-slate-300 dark:text-slate-600 py-6 text-center text-[10px]">
                        <BookOpen className="w-4 h-4 mb-1 text-slate-200 dark:text-slate-700" />
                        No lessons
                      </div>
                    ) : (
                      dayLessons.map((lesson) => {
                        const style = getSubjectStyles(lesson.subject);
                        return (
                          <div
                            key={lesson.id}
                            id={`week-lesson-${lesson.id}`}
                            onClick={() => onSelectLesson(lesson)}
                            className={`p-2 rounded-lg border ${style.bg} ${style.border} cursor-pointer hover:shadow-xs hover:scale-[1.01] transition-all flex flex-col gap-1 text-left`}
                          >
                            <div className="flex items-center gap-1">
                              <span className={`w-1.5 h-1.5 rounded-full ${style.dot}`} />
                              <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide truncate">
                                {lesson.subject}
                              </span>
                            </div>
                            <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-200 leading-tight line-clamp-2">
                              {lesson.title}
                            </h4>
                            <div className="flex items-center gap-1.5 text-[9px] text-slate-500 dark:text-slate-400 font-mono mt-1">
                              <Clock className="w-3 h-3 text-slate-400 dark:text-slate-500" />
                              <span>{lesson.startTime} - {lesson.endTime}</span>
                            </div>
                            <span className="text-[9px] px-1.5 py-0.5 bg-white/70 dark:bg-slate-800/70 rounded self-start border border-slate-100 dark:border-slate-750 text-slate-600 dark:text-slate-350 mt-1 font-sans flex items-center gap-1">
                              👤 {lesson.gradeLevel}
                            </span>
                          </div>
                        );
                      })
                    )}

                    {isTeacher && (
                      <button
                        onClick={() => onCreateLesson(dateStr)}
                        className="py-1.5 border border-dashed border-slate-200 dark:border-slate-800 hover:border-slate-400 dark:hover:border-slate-600 text-[10px] text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 rounded-lg flex items-center justify-center gap-1 cursor-pointer transition-all mt-auto"
                      >
                        <Plus className="w-3 h-3" /> Add Lesson
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW: DAY */}
        {viewType === "day" && (
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 max-w-2xl mx-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-base font-semibold text-slate-800 dark:text-slate-200">
                  {currentDate.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Daily agenda for {isToday(currentDate) ? "Today" : "Selected Date"}
                </p>
              </div>
              {isTeacher && (
                <button
                  onClick={() => onCreateLesson(currentDate.toISOString().split("T")[0])}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-medium hover:bg-indigo-700 flex items-center gap-1 cursor-pointer shadow-sm transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" /> Schedule Lesson
                </button>
              )}
            </div>

            <div className="flex flex-col gap-3 pt-4">
              {getLessonsForDate(currentDate).length === 0 ? (
                <div className="py-12 flex flex-col items-center justify-center text-slate-400 dark:text-slate-600">
                  <Calendar className="w-10 h-10 mb-2 text-slate-200 dark:text-slate-800" />
                  <p className="text-sm font-medium">No learning activities scheduled yet.</p>
                  <p className="text-xs text-slate-400 dark:text-slate-550 mt-1">Select month view or hit schedule to add a topic.</p>
                </div>
              ) : (
                getLessonsForDate(currentDate).map((lesson) => {
                  const style = getSubjectStyles(lesson.subject);
                  return (
                    <div
                      key={lesson.id}
                      id={`day-lesson-${lesson.id}`}
                      onClick={() => onSelectLesson(lesson)}
                      className={`p-4 rounded-xl border ${style.bg} ${style.border} cursor-pointer hover:shadow-md transition-all flex flex-col md:flex-row md:items-center justify-between gap-4`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider text-white ${style.dot}`}>
                            {lesson.subject}
                          </span>
                          <span className="text-xs text-slate-605 dark:text-slate-300 font-medium flex items-center gap-1">
                            👤 {lesson.gradeLevel}
                          </span>
                          <span className="text-xs text-slate-400 dark:text-slate-600">•</span>
                          <span className="text-xs text-indigo-600 dark:text-indigo-400 font-mono font-medium">
                            {lesson.duration}m duration
                          </span>
                        </div>
                        <h4 className="text-base font-bold text-slate-900 dark:text-slate-155 mb-1 leading-snug">
                          {lesson.title}
                        </h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                          {lesson.objectives || "No objectives declared yet."}
                        </p>
                      </div>

                      <div className="flex items-center gap-4 bg-white/70 dark:bg-slate-800/70 p-2.5 rounded-lg border border-slate-100 dark:border-slate-750 self-start md:self-auto">
                        <Clock className="w-4 h-4 text-indigo-500" />
                        <div className="flex flex-col">
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                            {lesson.startTime}
                          </span>
                          <span className="text-[9px] text-slate-400 dark:text-slate-500 font-mono uppercase">
                            to {lesson.endTime}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>

      {/* Small Subject Legends footer */}
      <div className="p-3 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-4 text-[10px] text-slate-500 dark:text-slate-400">
        <span className="font-semibold text-slate-700 dark:text-slate-300">Subject Legend:</span>
        {Object.entries(SUBJECT_COLORS).map(([subject, config]) => (
          <div key={subject} className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${config.dot}`} />
            <span>{subject}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
