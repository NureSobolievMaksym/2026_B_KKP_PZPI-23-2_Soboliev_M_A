export type UserRole = 'teacher' | 'student';

export interface AppUser {
  id: string;
  username?: string;
  name: string;
  role: UserRole;
  avatar: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
  role: 'teacher' | 'student' | 'both';
}

export interface LessonComment {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  text: string;
  timestamp: string; // ISO String
}

export interface Lesson {
  id: string;
  title: string;
  subject: string;
  gradeLevel: string;
  duration: number; // in minutes
  date: string; // "YYYY-MM-DD"
  startTime: string; // "HH:MM"
  endTime: string; // "HH:MM"
  objectives: string;
  outline: string; // markdown content
  materials: string[];
  checklist: ChecklistItem[];
  comments: LessonComment[];
  status: 'draft' | 'scheduled' | 'active' | 'completed';
  teachers: string[];
  students: string[];
  reminders: number[]; // minutes before standard triggers, e.g. [5, 15, 30]
  color?: string; // Hex or tailwind class
}

export interface Presence {
  userId: string;
  userName: string;
  userRole: UserRole;
  activeLessonId: string | null;
  lastSeen: string; // ISO String
}

export interface NotificationAlert {
  id: string;
  lessonId: string;
  lessonTitle: string;
  minutesBefore: number;
  triggerTime: string; // ISO String
  message: string;
  isRead: boolean;
  timestamp: string; // ISO String
}
