import React, { useState, useEffect } from "react";
import { Lesson, AppUser, Presence, NotificationAlert } from "./types";
import UserSelectionBar from "./components/UserSelectionBar";
import CalendarView from "./components/CalendarView";
import LessonDetailPanel from "./components/LessonDetailPanel";
import NotificationCenter from "./components/NotificationCenter";
import AuthView from "./components/AuthView";
import CreateLessonModal from "./components/CreateLessonModal";
import { 
  Bell, Calendar as CalendarIcon, FileText, Users, Clock, BookOpen, 
  HelpCircle, Volume2, BellRing, Settings, Info, CheckSquare, MessageSquare, AlertCircle,
  Sun, Moon
} from "lucide-react";

export default function App() {
  // Authentication session state saved in localStorage for multi-browser support
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    try {
      const stored = localStorage.getItem("academy_active_user");
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (err) {
      console.warn("Could not reload authenticated user:", err);
    }
    return null;
  });

  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [selectedCreateDate, setSelectedCreateDate] = useState<string | null>(null);
  
  // Light/Dark Theme selector state with localStorage persistence
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const storedTheme = localStorage.getItem("academy_theme");
      if (storedTheme) {
        return storedTheme === "dark";
      }
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    } catch (e) {
      return false;
    }
  });

  useEffect(() => {
    try {
      if (isDarkMode) {
        document.documentElement.classList.add("dark");
        localStorage.setItem("academy_theme", "dark");
      } else {
        document.documentElement.classList.remove("dark");
        localStorage.setItem("academy_theme", "light");
      }
    } catch (e) {
      console.warn("Could not write theme settings:", e);
    }
  }, [isDarkMode]);

  // Real-time synchronization state
  const [presences, setPresences] = useState<Presence[]>([]);
  const [sseStatus, setSseStatus] = useState<"connecting" | "connected" | "disconnected">("connecting");
  const [sseClientsCount, setSseClientsCount] = useState<number>(1);
  
  // Automated notifications list & triggers trackers
  const [alerts, setAlerts] = useState<NotificationAlert[]>([]);
  const [alertsTriggeredHistory, setAlertsTriggeredHistory] = useState<Record<string, boolean>>({});
  const [toastAlert, setToastAlert] = useState<NotificationAlert | null>(null);
  const [browserNotificationsEnabled, setBrowserNotificationsEnabled] = useState(false);

  // Layout states
  const [showNotificationCenter, setShowNotificationCenter] = useState(false);
  const [showAboutInfo, setShowAboutInfo] = useState(true);

  // 1. SSE Real-time Updates Handlers
  useEffect(() => {
    let sse: EventSource | null = null;
    let reconnectTimeout: NodeJS.Timeout;

    function connectSSE() {
      setSseStatus("connecting");
      const url = currentUser 
        ? `/api/events?userId=${encodeURIComponent(currentUser.id)}&role=${encodeURIComponent(currentUser.role)}`
        : "/api/events";
      sse = new EventSource(url);

      sse.onopen = () => {
        setSseStatus("connected");
      };

      sse.onerror = () => {
        setSseStatus("disconnected");
        // Auto reconnect schedules
        sse?.close();
        reconnectTimeout = setTimeout(connectSSE, 5000);
      };

      sse.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          
          if (payload.type === "handshake") {
            // Handshake confirmed
          } else if (payload.type === "sync_lessons") {
            setLessons(payload.data);
            if (activeLesson) {
              const fresh = payload.data.find((l: Lesson) => l.id === activeLesson.id);
              if (fresh && JSON.stringify(fresh) !== JSON.stringify(activeLesson)) {
                setActiveLesson(fresh);
              }
            }
          } else if (payload.type === "lessons_updated") {
            // Предотвращаем ререндер списка уроков, если контент идентичен
            setLessons(prevLessons => {
              if (JSON.stringify(prevLessons) === JSON.stringify(payload.data)) {
                return prevLessons;
              }
              return payload.data;
            });

            // Умное обновление активного урока без сброса фокуса ввода
            if (activeLesson) {
              const fresh = payload.data.find((l: Lesson) => l.id === activeLesson.id);
              if (fresh) {
                if (JSON.stringify(fresh) !== JSON.stringify(activeLesson)) {
                  setActiveLesson(prevActive => {
                    if (!prevActive) return fresh;

                    // Вычисляем, какие именно узлы изменились
                    const commentsChanged = JSON.stringify(prevActive.comments) !== JSON.stringify(fresh.comments);
                    const checklistChanged = JSON.stringify(prevActive.checklist) !== JSON.stringify(fresh.checklist);
                    const coreFieldsChanged = 
                      prevActive.title !== fresh.title ||
                      prevActive.outline !== fresh.outline ||
                      prevActive.objectives !== fresh.objectives ||
                      prevActive.status !== fresh.status ||
                      JSON.stringify(prevActive.materials) !== JSON.stringify(fresh.materials);

                    // Если текстовые поля (title, outline) не менялись, а прилетели только чек-листы или комменты — 
                    // мержим точечно. Это сохраняет фокус в инпутах, если кто-то другой пишет коммент или кликает чек-лист.
                    if (!coreFieldsChanged && (commentsChanged || checklistChanged)) {
                      return {
                        ...prevActive,
                        checklist: fresh.checklist,
                        comments: fresh.comments
                      };
                    }

                    // Если изменилось ядро документа (например, глобальный апдейт описания), обновляем ссылку
                    return fresh;
                  });
                }
              }
            }
          } else if (payload.type === "presence_changed") {
            setPresences(prev => {
              if (JSON.stringify(prev) === JSON.stringify(payload.data)) return prev;
              return payload.data;
            });
            setSseClientsCount(payload.data.length || 1);
          }
        } catch (e) {
          console.error("Error parsing real-time channel message:", e);
        }
      };
    }

    connectSSE();

    return () => {
      sse?.close();
      clearTimeout(reconnectTimeout);
    };
  }, [activeLesson, currentUser]); // Следим за состоянием активного урока для актуальных диффов

  // 2. Active Presence Heartbeats & Logs Reports
  useEffect(() => {
    if (!currentUser) return;

    const reportPresence = async () => {
      try {
        await fetch("/api/presence", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: currentUser.id,
            userName: currentUser.name,
            userRole: currentUser.role,
            activeLessonId: activeLesson?.id || null
          })
        });
      } catch (err) {
        // safe ignore trace
      }
    };

    reportPresence();
    const interval = setInterval(reportPresence, 6000);

    return () => clearInterval(interval);
  }, [currentUser, activeLesson?.id]);

  // 3. Automated Notification Scheduler check (Runs every 4 seconds)
  useEffect(() => {
    const checkScheduleForReminders = () => {
      const now = new Date();
      const todayISO = now.toISOString().split('T')[0];

      lessons.forEach((lesson) => {
        if (lesson.status !== "scheduled" && lesson.status !== "active") return;
        if (lesson.date !== todayISO) return;

        try {
          const [startH, startM] = lesson.startTime.split(":").map(Number);
          const startDateTime = new Date(now);
          startDateTime.setHours(startH, startM, 0, 0);

          const diffMs = startDateTime.getTime() - now.getTime();
          const diffMins = Math.ceil(diffMs / 60000);

          lesson.reminders.forEach((reminderMin) => {
            const isMatch = diffMins === reminderMin;
            const alertKey = `${lesson.id}-${reminderMin}-triggered`;

            if (isMatch && !alertsTriggeredHistory[alertKey]) {
              triggerNotificationAlert({
                id: "alert-" + Date.now().toString() + Math.random().toString(36).substring(2, 4),
                lessonId: lesson.id,
                lessonTitle: lesson.title,
                minutesBefore: reminderMin,
                triggerTime: new Date().toISOString(),
                message: `Class session is starting in ${reminderMin} minutes! Gather study materials and review checklists.`,
                isRead: false,
                timestamp: new Date().toISOString()
              });

              setAlertsTriggeredHistory(prev => ({ ...prev, [alertKey]: true }));
            }
          });
        } catch (e) {
          // date parsing failsafe
        }
      });
    };

    const interval = setInterval(checkScheduleForReminders, 4000);
    return () => clearInterval(interval);
  }, [lessons, alertsTriggeredHistory]);

  const triggerNotificationAlert = (alert: NotificationAlert) => {
    setAlerts((prev) => [alert, ...prev]);
    setToastAlert(alert);

    setTimeout(() => {
      setToastAlert((curr) => (curr?.id === alert.id ? null : curr));
    }, 9000);

    playChime();

    if (browserNotificationsEnabled && window.Notification && Notification.permission === "granted") {
      new Notification(`CollabAcademy: ${alert.lessonTitle}`, {
        body: alert.message,
        icon: "https://cdn-icons-png.flaticon.com/512/3233/3233984.png"
      });
    }
  };

  const playChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(440, audioCtx.currentTime);
      oscillator.frequency.setValueAtTime(554.37, audioCtx.currentTime + 0.12);
      oscillator.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.24);
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime + 0.36);

      gainNode.gain.setValueAtTime(0.06, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.8);

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.8);
    } catch (e) {
      // Blocked or unsupported
    }
  };

  const handleEnableBrowserNotifications = async () => {
    if (!window.Notification) {
      alert("This browser does not support default OS system notifications.");
      return;
    }

    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      setBrowserNotificationsEnabled(true);
      new Notification("Desktop Alerts Active!", {
        body: "CollabAcademy real-time automated alerts will prompt here.",
        tag: "test-alert"
      });
    } else {
      alert("Notification access declined. Simulated in-app alerts will continue to work perfectly!");
    }
  };

  const handleScheduleTestNotification = (lessonId: string, secondsInFuture: number) => {
    const target = lessons.find((l) => l.id === lessonId);
    if (!target) return;

    const confirmAlert: NotificationAlert = {
      id: "alert-confirm-" + Date.now(),
      lessonId: target.id,
      lessonTitle: target.title,
      minutesBefore: 99,
      triggerTime: new Date().toISOString(),
      message: `Automated testing counter activated! Alert queued to trigger in ${secondsInFuture} seconds. Keep this tab open to test.`,
      isRead: false,
      timestamp: new Date().toISOString()
    };
    setAlerts((prev) => [confirmAlert, ...prev]);

    setTimeout(() => {
      const realTriggerAlert: NotificationAlert = {
        id: "alert-test-triggered-" + Date.now(),
        lessonId: target.id,
        lessonTitle: target.title,
        minutesBefore: 1,
        triggerTime: new Date().toISOString(),
        message: `[TEST TRIGGER] Automated reminder notification prompt testing successful! Class preparation timers have concluded nicely.`,
        isRead: false,
        timestamp: new Date().toISOString()
      };
      triggerNotificationAlert(realTriggerAlert);
    }, secondsInFuture * 1000);
  };

  const handleUpdateLesson = async (updatedFields: Partial<Lesson>) => {
    if (!activeLesson) return;
    
    try {
      const optimistic = { ...activeLesson, ...updatedFields } as Lesson;
      setActiveLesson(optimistic);

      const response = await fetch(`/api/lessons/${activeLesson.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedFields)
      });

      if (!response.ok) {
        throw new Error("Updates rejected from lesson planner server");
      }
    } catch (err) {
      console.error("Error writing lesson update:", err);
    }
  };

  const handleAddComment = async (text: string) => {
    if (!activeLesson) return;

    try {
      const response = await fetch(`/api/lessons/${activeLesson.id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authorId: currentUser.id,
          authorName: currentUser.name,
          authorRole: currentUser.role,
          text
        })
      });

      if (!response.ok) {
        throw new Error("Unable to save comment logs");
      }
    } catch (e) {
      console.error("Failed to add collaborative chat log:", e);
    }
  };

  const handleDeleteLesson = async (id: string) => {
    try {
      const response = await fetch(`/api/lessons/${id}`, {
        method: "DELETE"
      });

      if (response.ok) {
        if (activeLesson?.id === id) {
          setActiveLesson(null);
        }
      }
    } catch (err) {
      console.error("Error deleting lesson plan:", err);
    }
  };

  const handleCreateNewLessonPlan = (dateStr: string) => {
    setSelectedCreateDate(dateStr);
  };

  const handleConfirmCreateLesson = async (data: {
    title: string;
    subject: string;
    gradeLevel: string;
    duration: number;
    startTime: string;
    endTime: string;
    status: 'draft' | 'scheduled' | 'active' | 'completed';
  }) => {
    if (!selectedCreateDate) return;

    try {
      const response = await fetch("/api/lessons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...data,
          date: selectedCreateDate
        })
      });

      if (response.ok) {
        const body = await response.json();
        setActiveLesson(body);
        playChime();
      } else {
        throw new Error("Syllabus item could not be published to backend storage.");
      }
    } catch (e) {
      console.error("Error creating lesson plan:", e);
    }
  };

  const handleMarkAlertRead = (id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, isRead: true } : a)));
  };

  const handleClearAlerts = () => {
    setAlerts([]);
  };

  const handleLoginSuccess = (user: AppUser) => {
    localStorage.setItem("academy_active_user", JSON.stringify(user));
    setCurrentUser(user);
    try {
      playChime();
    } catch (e) {}
  };

  const handleSignOut = () => {
    localStorage.removeItem("academy_active_user");
    setCurrentUser(null);
    setActiveLesson(null);
  };

  if (!currentUser) {
    return <AuthView onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div id="full-dashboard-app" className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col font-sans text-slate-800 dark:text-slate-100 antialiased selection:bg-indigo-100 selection:dark:bg-indigo-900">
      
      <UserSelectionBar 
        currentUser={currentUser} 
        onSignOut={handleSignOut} 
        onlineCount={sseClientsCount}
      />

      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-40 px-4 py-4 shadow-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-lg text-white">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-extrabold text-slate-900 dark:text-slate-100 tracking-tight leading-tight flex items-center gap-2">
                Co-Learn Lesson Planner
              </h1>
              <p className="text-xs text-slate-505 dark:text-slate-400 hidden sm:inline">Collaborative syllabus and scheduling hub</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              id="theme-toggle"
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2.5 rounded-full border border-slate-200 dark:border-slate-805 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer transition-colors"
              title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              id="header-bell-toggle"
              onClick={() => {
                setShowNotificationCenter(!showNotificationCenter);
                playChime();
              }}
              className="p-2.5 rounded-full border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-350 relative cursor-pointer hover:border-slate-305 transition-all flex items-center gap-1.5"
            >
              {alerts.filter(a => !a.isRead).length > 0 ? (
                <>
                  <BellRing className="w-4 h-4 text-amber-500 animate-pulse" />
                  <span className="w-2.5 h-2.5 bg-rose-500 absolute top-1 right-1 rounded-full border border-white dark:border-slate-900" />
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 hidden sm:inline">
                    {alerts.filter(a => !a.isRead).length} Alerts
                  </span>
                </>
              ) : (
                <>
                  <Bell className="w-4 h-4" />
                  <span className="text-xs text-slate-400 dark:text-slate-550 hidden sm:inline">Alert Alerts</span>
                </>
              )}
            </button>

            {!browserNotificationsEnabled && (
              <button
                id="btn-opt-in-browser-alerts"
                onClick={handleEnableBrowserNotifications}
                className="hidden md:flex items-center gap-1 text-[11px] font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-805 dark:hover:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-950/40 px-3 py-2 rounded-lg cursor-pointer transition-colors"
                title="Integrate operating system sound / banner notices"
              >
                <Volume2 className="w-3.5 h-3.5" /> Opt-in OS Alerts
              </button>
            )}

          </div>
        </div>
      </header>

      {toastAlert && (
        <div 
          id="toast-notification-banner"
          className="fixed bottom-4 right-4 z-50 bg-slate-900 dark:bg-slate-950 text-white p-4 rounded-xl border border-indigo-500 shadow-xl max-w-sm flex gap-3 animate-slide-in"
        >
          <div className="p-2 bg-indigo-950 text-indigo-400 rounded-lg shrink-0">
            <BellRing className="w-5 h-5 animate-bounce" />
          </div>
          <div className="flex-1 text-left">
            <h5 className="font-bold text-xs">Automated reminder triggered</h5>
            <p className="text-xs font-semibold text-indigo-400 leading-tight mt-0.5">
              {toastAlert.lessonTitle}
            </p>
            <p className="text-[10px] text-slate-300 mt-1 leading-relaxed">
              {toastAlert.message}
            </p>
            <button
              onClick={() => setToastAlert(null)}
              className="text-[10px] text-slate-400 mt-2 font-bold hover:text-indigo-300 pointer-events-auto"
            >
              Acknowledge & Close
            </button>
          </div>
        </div>
      )}


      <main className="flex-1 w-full max-w-7xl mx-auto px-4 lg:px-6 py-6 flex flex-col md:flex-row gap-6">
        <section className="flex-1 flex flex-col gap-4 min-w-0">
          {activeLesson ? (
            <div className="h-full flex flex-col min-h-[500px]">
              <div className="pb-3 flex items-center justify-between">
                <button
                  id="btn-detail-back-arrow"
                  onClick={() => {
                    setActiveLesson(null);
                    playChime();
                  }}
                  className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-305 flex items-center gap-1 cursor-pointer"
                >
                  ← Return to Calendar Grid
                </button>
                <div className="text-slate-400 dark:text-slate-500 text-xs font-mono">
                  Syllabus Document: <span className="font-bold text-slate-600 dark:text-slate-400">{activeLesson.id}</span>
                </div>
              </div>

              <div className="flex-1">
                <LessonDetailPanel
                  lesson={activeLesson}
                  currentUser={currentUser}
                  presences={presences}
                  onUpdateLesson={handleUpdateLesson}
                  onAddComment={handleAddComment}
                  onDeleteLesson={handleDeleteLesson}
                  onClose={() => {
                    setActiveLesson(null);
                    playChime();
                  }}
                />
              </div>
            </div>
          ) : (
            <div className="h-full">
              <CalendarView
                lessons={lessons}
                onSelectLesson={(lesson) => {
                  setActiveLesson(lesson);
                  playChime();
                }}
                onCreateLesson={handleCreateNewLessonPlan}
                isTeacher={currentUser.role === 'teacher'}
              />
            </div>
          )}
        </section>

        {showNotificationCenter && (
          <aside className="w-full md:w-80 shrink-0 select-none animate-slide-in">
            <NotificationCenter
              alerts={alerts}
              lessons={lessons}
              onMarkRead={handleMarkAlertRead}
              onClearAll={handleClearAlerts}
              onScheduleTestNotification={handleScheduleTestNotification}
              onClose={() => setShowNotificationCenter(false)}
            />
          </aside>
        )}
      </main>

      {selectedCreateDate && (
        <CreateLessonModal
          isOpen={!!selectedCreateDate}
          dateStr={selectedCreateDate}
          currentUser={currentUser}
          onClose={() => setSelectedCreateDate(null)}
          onSubmit={handleConfirmCreateLesson}
        />
      )}

      <footer className="bg-slate-900 text-slate-400 py-6 border-t border-slate-800 text-xs text-center mt-12 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-3.5 h-3.5" />
            <span>CollabAcademy Schedule System</span>
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5 text-slate-500">
              <span className={`w-2 h-2 rounded-full ${sseStatus === "connected" ? "bg-emerald-500" : "bg-rose-500"}`} />
              <span className="capitalize">{sseStatus} SSE Channel</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}